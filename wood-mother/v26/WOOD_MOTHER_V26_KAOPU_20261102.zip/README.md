# KAOPU Wood Mother V26 — 函数与工作台交接

固定公网预览：https://kaopu-wood-mother-r01.sunhaihao.chatgpt.site/v26

`wood-functions/` 为源码、示例对象与连接、许可、规则和接入说明，先读其 README；`workbench/v26.html` 与同目录 logo 为此版独立工作台快照。Node.js 执行 `node wood-functions/verify-handoff.cjs` 可检查函数入口。发布前未把原始参考照片、图纸、扫描、模型或原轮廓包含进此包。工作台演示不是建筑具体来源测量或真实风化模型。保留 MIT 许可；更多技术边界见 `wood-functions/README.md`。

本包对应 Wood Mother 来源提交 b85d20f53a1f690dd6e04ac13efb3be461f1b15c；它是挑选的可复用发布包，不是全部 Git 历史，也不表示已完成接入任何具体建筑。

/* Original KAOPU WoodExposure growth-albedo-r02 experiment. binary64, local Y longitudinal; source is fields, not textures.
   height is NORMAL-ONLY relief. Boundary erosion belongs to WoodShapes' analytic primitives. */
(function(root){
const RI=typeof require==='function'?require('./filter.js'):root.KAOPURidgeInterval;
const axes=fp=>typeof fp==='number'?null:fp;
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v)),mix=(a,b,t)=>a+(b-a)*t;
function hash(x,y,z,seed=1709){let h=Math.imul(x,374761393)^Math.imul(y,668265263)^Math.imul(z,2147483647)^seed;h=Math.imul(h^(h>>>13),1274126177);return ((h^(h>>>16))>>>0)/4294967296}
function noise(x,y,z,seed){const ix=Math.floor(x),iy=Math.floor(y),iz=Math.floor(z),tx=x-ix,ty=y-iy,tz=z-iz,u0=tx*tx*(3-2*tx),u1=ty*ty*(3-2*ty),u2=tz*tz*(3-2*tz),d0=6*tx*(1-tx),d1=6*ty*(1-ty),d2=6*tz*(1-tz);let v=0,g0=0,g1=0,g2=0;for(let a=0;a<2;a++)for(let b=0;b<2;b++)for(let c=0;c<2;c++){const h=hash(ix+a,iy+b,iz+c,seed),w0=a?u0:1-u0,w1=b?u1:1-u1,w2=c?u2:1-u2;v+=h*w0*w1*w2;g0+=h*(a?1:-1)*d0*w1*w2;g1+=h*(b?1:-1)*d1*w0*w2;g2+=h*(c?1:-1)*d2*w0*w1}return {v,g:[g0,g1,g2]}}
const presets={pale:{base:[.39,.29,.18],ridge:[.62,.53,.39],recess:[.16,.11,.063]},dark:{base:[.105,.071,.039],ridge:[.22,.16,.093],recess:[.038,.025,.014]},red:{base:[.23,.069,.029],ridge:[.38,.16,.069],recess:[.065,.018,.009]}};

// Versioned visual recipes, not species identification. No geometry/seed mutation.
const profiles=[
 {id:0,name:'针叶浅旧',density:1,long:1,relief:1,ring:30,contrast:1,wave:0,rate:1,rough:0,coat:0,coatRough:.6,style:'pale'},
 {id:1,name:'粗纹配方',density:.62,long:.72,relief:1.18,ring:19,contrast:1.4,wave:.009,rate:1.5,rough:-.03,coat:0,coatRough:.6,style:'pale',base:[.28,.16,.072],ridge:[.52,.35,.16],recess:[.085,.042,.018]},
 {id:2,name:'细纹配方',density:1.9,long:.55,relief:.45,ring:43,contrast:.48,wave:.004,rate:1.3,rough:-.12,coat:.07,coatRough:.38,style:'pale',base:[.46,.32,.19],ridge:[.66,.51,.33],recess:[.23,.14,.075]},
 {id:3,name:'中纹配方',density:.95,long:.8,relief:.8,ring:25,contrast:1.1,wave:.012,rate:1.7,rough:-.10,coat:.12,coatRough:.34,style:'pale',base:[.24,.12,.051],ridge:[.46,.28,.12],recess:[.068,.030,.013]},
 {id:4,name:'交错纹',density:1.25,long:.65,relief:.78,ring:28,contrast:.7,wave:.036,rate:5,rough:-.16,coat:.24,coatRough:.28,style:'dark'},
 {id:5,name:'波状纹',density:1.05,long:.65,relief:.8,ring:27,contrast:.85,wave:.055,rate:3,rough:-.12,coat:.18,coatRough:.32,style:'pale'},
 {id:6,name:'红木风格',density:1.55,long:.65,relief:.48,ring:35,contrast:.75,wave:.017,rate:2.4,rough:-.24,coat:.42,coatRough:.19,style:'red'},
 {id:7,name:'金丝楠风格',density:1.85,long:.55,relief:.5,ring:37,contrast:.6,wave:.028,rate:3.8,rough:-.21,coat:.34,coatRough:.22,style:'pale',base:[.30,.22,.075],ridge:[.60,.49,.21],recess:[.11,.072,.024]}
];
function profileOf(id=0){if(!Number.isInteger(id)||id<0||id>=profiles.length)throw new RangeError('Unsupported WoodExposure profile');return profiles[id]}

function organization(p,par={},footprint=0){
 const seed=par.seed??1709,ex=clamp(par.exposure??.85),damage=clamp(par.damage??.75),lean=par.fiberLean??.025,curve=par.fiberCurve??.012;
 const x=p[0]-lean*p[1]-curve*p[1]*p[1],y=p[1],z=p[2],warpDerivative=lean+2*curve*y;
 const macro=noise(x*3.1,y*.55,z*3.1,seed+67),exposure=ex*(.65+.35*macro.v);
 let height=0,grad=[0,0,0],gully=0,ridge=0,unresolved=0;
 for(const [f0,fy,amp,k] of [[39,1.2,.016,0],[87,9.2,.0054,1],[179,23,.0018,2]]){
  const freq=f0*clamp(par.grainDensity??1,.4,2.5),longFreq=fy*(par._long??1),n=noise(x*freq,y*longFreq,z*freq,seed+101*k),r=2*n.v-1,gg=[n.g[0]*freq,n.g[1]*longFreq-n.g[0]*freq*warpDerivative,n.g[2]*freq],rg=gg.map(v=>v*2);
  let delta,band;const fp=axes(footprint);
  if(fp){delta=.5*(Math.abs(fp.dx.reduce((s,v,i)=>s+v*rg[i],0))+Math.abs(fp.dy.reduce((s,v,i)=>s+v*rg[i],0)));band=Math.max(...[fp.dx,fp.dy].map(v=>Math.hypot((v[0]-warpDerivative*v[1])*freq,v[1]*longFreq,v[2]*freq)));}
  else{delta=.5*footprint*rg.reduce((s,v)=>s+Math.abs(v),0);band=footprint*freq;}
  const filtered=RI.average(r,delta),cross=clamp((band-.55)/.95),lost=cross*cross*(3-2*cross),h=mix(filtered.value,.49988568031047664,lost),der=filtered.derivative*(1-lost),power=amp*(par._relief??1)*(.35+.65*damage)*exposure;
  height+=power*h;for(let j=0;j<3;j++)grad[j]+=power*der*rg[j];
  ridge+=h/[1.6,3,6][k];gully+=(1-h)/[1.6,3,6][k];
  const attenuation=clamp(delta/.6),slopeLoss=1-(1-lost)*(1-attenuation);unresolved+=slopeLoss*power*freq*Math.sqrt(.6019052308015957)*.16;
 }
 if(exposure>0){const f=height/exposure*ex*.35,mg=[macro.g[0]*3.1,macro.g[1]*.55-macro.g[0]*3.1*warpDerivative,macro.g[2]*3.1];for(let j=0;j<3;j++)grad[j]+=f*mg[j];}
 return {version:'WoodExposure/profiles-r01',seed,height,gradient:grad,ridge,gully,exposure,damage,roughVariance:unresolved,macro:macro.v};
}
function queryDamageEvents(p,events=[]){let influence=0;for(const e of events){if(e.kind!=='ellipsoid-void')continue;const a=e.angleY||0,c=Math.cos(a),s=Math.sin(a),dx=p[0]-e.center[0],dz=p[2]-e.center[2],q=Math.hypot((c*dx-s*dz)/e.radii[0],(p[1]-e.center[1])/e.radii[1],(s*dx+c*dz)/e.radii[2]),t=clamp((q-.85)/.8);influence=Math.max(influence,(1-t*t*(3-2*t))*clamp(e.strength??1));}return influence;}
function knotLayout(seed=1709,style=0,offset=0,scale=1){
 if(!Number.isInteger(style)||style<0||style>2)throw new RangeError('Unsupported knot style');
 if(style===0)return [{y:-.65+1.3*hash(3,7,11,seed)+offset,x:-.12+.24*hash(13,7,11,seed),size:(.145+.085*hash(23,7,11,seed))*scale}];
 const count=style===1?3:5;return Array.from({length:count},(_,i)=>({y:-.72+1.44*i/(count-1)+.08*(hash(3+47*i,7,11,seed)-.5)+offset,x:-.16+.32*hash(13+47*i,7,11,seed),size:(.13+.05*hash(23+47*i,7,11,seed))*scale}));
}
function evaluateCore(p,ng,par={},footprint=0){
 const profile=profileOf(par.profile);

 const knots=knotLayout(par.seed??1709,par.knotStyle??0,par.knotOffset??0,par.knotScale??1),zT=clamp((p[2]+.08)/.36),zw=zT*zT*(3-2*zT),zDerivative=6*zT*(1-zT)/.36,jac=[1,0,0];let warp=0;
 for(const k of knots){const span=k.size*1.82,cross=k.size*.5263,wy=p[1]-k.y,wx=(p[0]-k.x)/cross,e=Math.exp(-wy*wy/(span*span)),th=Math.tanh(wx),amp=.075*k.size/.19;warp+=amp*e*th*zw;jac[0]+=amp*e*(1-th*th)/cross*zw;jac[1]+=amp*e*th*(-2*wy/(span*span))*zw;jac[2]+=amp*e*th*zDerivative;}
 const q=[p[0]+warp,p[1],p[2]],fpAxes=axes(footprint),flowFootprint=fpAxes?{dx:[jac.reduce((v,x,i)=>v+x*fpAxes.dx[i],0),fpAxes.dx[1],fpAxes.dx[2]],dy:[jac.reduce((v,x,i)=>v+x*fpAxes.dy[i],0),fpAxes.dy[1],fpAxes.dy[2]]}:footprint;
 const f=organization(q,par,flowFootprint),gx=f.gradient[0];f.gradient=[gx*jac[0],gx*jac[1]+f.gradient[1],gx*jac[2]+f.gradient[2]];
 const palette=profile.base?profile:(presets[profile.id?profile.style:(par.style||profile.style)]||presets.pale);
 // A single radial growth coordinate across cut end and longitudinal side. Not a UV decal.
 const y=p[1],x=p[0]-(par.fiberLean??.025)*y-(par.fiberCurve??.012)*y*y,z=p[2],rho=Math.hypot(x+.07,z-.04),theta=Math.atan2(z-.04,x+.07);
 const fp=axes(footprint),radial=[(x+.07)/Math.max(rho,1e-9),-(par.fiberLean??.025)*((x+.07)/Math.max(rho,1e-9))-2*(par.fiberCurve??.012)*y*((x+.07)/Math.max(rho,1e-9)),(z-.04)/Math.max(rho,1e-9)];let radialFootprint=fp?Math.hypot(fp.dx.reduce((v,x,i)=>v+x*radial[i],0),fp.dy.reduce((v,x,i)=>v+x*radial[i],0)):footprint;
 let growthRho=rho,growthGradient=radial.slice(),knotWeight=0,knotCore=0;
 for(const k of knots){const branch=Math.hypot((x-k.x)*1.12,(y-k.y)*.55),envelope=Math.exp(-Math.pow(branch/k.size,4)),kw=envelope*zw,bx=1.12*1.12*(x-k.x)/Math.max(branch,1e-9),bg=[bx,.55*.55*(y-k.y)/Math.max(branch,1e-9)-((par.fiberLean??.025)+2*(par.fiberCurve??.012)*y)*bx,0],kg=bg.map(v=>v*kw*(-4*branch**3/k.size**4));kg[2]+=envelope*zDerivative;growthGradient=growthGradient.map((v,i)=>v*(1-.88*kw)+bg[i]*.88*kw+(branch+.09-growthRho)*.88*kg[i]);growthRho=mix(growthRho,branch+.09,kw*.88);knotWeight=1-(1-knotWeight)*(1-kw);knotCore=1-(1-knotCore)*(1-Math.exp(-((branch/(k.size*((par.knotStyle??0)? .42:.2526)))**2))*zw);}
 if(fp)radialFootprint=Math.hypot(fp.dx.reduce((v,x,i)=>v+x*growthGradient[i],0),fp.dy.reduce((v,x,i)=>v+x*growthGradient[i],0));
 const age=growthRho*(1+.055*Math.sin(theta*3+y*.3)+.018*Math.sin(theta*7)),phase=age*profile.ring*clamp(par.grainDensity??1,.4,2.5)+.8*noise(age*6,0,0,par.seed??1709).v+.10*Math.sin(theta*5+age*11),a=phase-Math.floor(phase),sigma=Math.sqrt(.105**2+(radialFootprint*(profile.ring+2)*clamp(par.grainDensity??1,.4,2.5)*.5)**2),rawRing=[-1,0,1].reduce((v,k)=>v+Math.exp(-(((a-.78+k)/sigma)**2))*.105/sigma,0),ring=mix(rawRing,.105*Math.sqrt(Math.PI),clamp((sigma-.35)/.3)),keep=1;
 const end=Math.abs(ng[1]),ringContrast=profile.contrast*(.36+.10*end)*ring*keep*(1-.45*knotWeight);
 const tint=clamp(.08+1.35*f.ridge-.55*f.gully),variation=.56+.70*f.macro;
 let base=palette.base.map((v,i)=>mix(v,palette.ridge[i],tint)*variation*(1-ringContrast));
 const recess=clamp(f.gully*.28);base=base.map((v,i)=>mix(v,palette.recess[i],recess));
 const endBase=palette.base.map((v,i)=>mix(v,palette.ridge[i],.22+.22*f.macro)*(1-.52*profile.contrast*ring*keep));base=base.map((v,i)=>mix(v,endBase[i],end*end));
 base=base.map((v,i)=>mix(v,palette.recess[i],knotCore*(1-end)*((par.knotStyle??0)? .85:.50))*((par.knotStyle??0)?1-.55*knotCore*(1-end):1));
 // Projection on tangent plane: no displacement, no silhouette claim.
 const g=f.gradient,along=g[0]*ng[0]+g[1]*ng[1]+g[2]*ng[2],normal=ng.map((v,i)=>v-(g[i]-v*along)*(1-end)),len=Math.hypot(...normal);
 const eventInfluence=queryDamageEvents(par._eventPoint||p,par.damageEvents||[]);base=base.map((v,i)=>mix(v,palette.ridge[i],eventInfluence*.30));
 if(par.surface==='chip')base=base.map((v,i)=>mix(v,palette.recess[i],.18*f.damage));
 const rough=clamp(profile.rough+eventInfluence*.07+(par.surface==='chip'?.73:.68)+.12*f.exposure+.09*f.gully+f.roughVariance,.45,.96);
 return {base,normal:normal.map(v=>v/len),rough,coat:profile.coat,coatRough:profile.coatRough,coatIOR:1.5,weather:clamp(f.exposure+eventInfluence*.1),eventInfluence,field:f};
}

function evaluate(p,ng,par={},footprint=0){
 const pr=profileOf(par.profile);if(pr.id===0)return evaluateCore(p,ng,par,footprint);
 const phase=pr.rate*p[1]+(par.seed??1709)%97*.061,shift=pr.wave*Math.sin(phase),der=pr.wave*pr.rate*Math.cos(phase),q=[p[0]+shift,p[1],p[2]],fp=axes(footprint),qfp=fp?{dx:[fp.dx[0]+der*fp.dx[1],fp.dx[1],fp.dx[2]],dy:[fp.dy[0]+der*fp.dy[1],fp.dy[1],fp.dy[2]]}:footprint*(1+Math.abs(der));
 const o=evaluateCore(q,ng,{...par,grainDensity:(par.grainDensity??1)*pr.density,_long:pr.long,_relief:pr.relief,_eventPoint:p},qfp),g=o.field.gradient;g[1]+=der*g[0];
 const end=Math.abs(ng[1]),along=g.reduce((a,v,i)=>a+v*ng[i],0),n=ng.map((v,i)=>v-(g[i]-v*along)*(1-end)),len=Math.hypot(...n);o.normal=n.map(v=>v/len);return o;
}

const api={version:'WoodExposure/profiles-r02',hash,noise,organization,queryDamageEvents,knotLayout,evaluate,presets,profiles,profileOf};if(typeof module!=='undefined'&&module.exports)module.exports=api;root.WoodExposure=api;
})(typeof globalThis!=='undefined'?globalThis:this);

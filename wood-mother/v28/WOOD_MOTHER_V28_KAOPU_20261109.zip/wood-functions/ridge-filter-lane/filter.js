/* Original interval convolution for phi(r)=(1-sqrt(r*r+epsilon))^2.
   Exact for a UNIFORM interval in a locally linear r field; not exact across noise cells. */
(function(root){
const E=.008,clamp=x=>Math.max(-1,Math.min(1,x));
function phi(r){r=clamp(r);const a=1-Math.sqrt(r*r+E);return a*a}
function derivative(r){if(r<=-1||r>=1)return 0;return 2*r*(1-1/Math.sqrt(r*r+E))}
function primitiveInside(r){const h=Math.sqrt(r*r+E);return (1+E)*r+r*r*r/3-r*h-E*Math.asinh(r/Math.sqrt(E))}
const end=primitiveInside(1),tail=phi(1);
function primitive(r){if(r>1)return end+(r-1)*tail;if(r< -1)return -end+(r+1)*tail;return primitiveInside(r)}
function average(r,delta){
 if(!(delta>0))return {value:phi(r),derivative:derivative(r)};
 if(delta<1e-4){
  if(Math.abs(r)-delta>=1)return {value:tail,derivative:0};
  if(Math.abs(r)+delta<1){const q=r*r+E,second=2-2*E/Math.pow(q,1.5),third=6*E*r/Math.pow(q,2.5);return {value:phi(r)+second*delta*delta/6,derivative:derivative(r)+third*delta*delta/6};}
  // Stable clipped endpoint Taylor integral; avoids subtracting nearly equal primitives.
  const b=r>=0?1:-1,w=Math.max(0,Math.min(2*delta,delta+(1-Math.abs(r)))),first=2*b*(1-1/Math.sqrt(1+E)),second=2-2*E/Math.pow(1+E,1.5);
  return {value:tail-b*first*w*w/(4*delta)+second*w*w*w/(12*delta),derivative:first*w/(2*delta)-b*second*w*w/(4*delta)};
 }
 return {value:(primitive(r+delta)-primitive(r-delta))/(2*delta),derivative:(phi(r+delta)-phi(r-delta))/(2*delta)};
}
const api={epsilon:E,phi,derivative,primitive,average,uniformMean:primitiveInside(1)};if(typeof module!=='undefined')module.exports=api;root.KAOPURidgeInterval=api;
})(typeof globalThis!=='undefined'?globalThis:this);

/* Public restricted KAOPU adapter. Demo dimensions are not measurements of reference images. */
(function(root){
'use strict';
const VERSION='WOOD-REFERENCE-MOTHER-R04';
const MATERIAL_SEED_VERSION='id-fnv1a32-r01';
function materialSeed(baseSeed,id){let h=(2166136261^baseSeed)>>>0;for(let i=0;i<id.length;i++)h=Math.imul(h^id.charCodeAt(i),16777619)>>>0;return (h^(h>>>16))>>>0;}
function source(overrides={},materialRecipe={},studyView='forms'){
 return {language:'KAOPU-TLO',version:VERSION,Time:{manufactured:null,created:'2026-10-28'},Location:{region:null,placement:null},Object:{studyView,id:'wood-reference-study',mother:VERSION,origin:'material-axis-midpoint',axes:'Y=longitudinal; X,Z=cross-section',units:'normalized-design-demo-not-measured',materialRecipe:{version:MATERIAL_SEED_VERSION,mode:'identity',overrides:{},...materialRecipe},parameters:{profile:0,length:2.8,width:.62,depth:.62,rounding:.055,damage:.45,grainDensity:1,exposure:.72,finish:0,jointWidth:.26,jointHeight:.28,clearance:.012,seed:17,knotStyle:0,crackStyle:0,...overrides},relations:studyView==='forms'?[{id:'frame-joint',type:'common-fit-domain',members:['frame-left','frame-crossbeam','frame-right'],evidence:'designed-demonstration-not-reconstructed'}]:[]}};
}
function expand(a){
 if(a?.language!=='KAOPU-TLO'||a.version!==VERSION||a.Object?.mother!==VERSION)throw Error('Unsupported reference authority');
 if(a.Object.origin!=='material-axis-midpoint'||a.Object.axes!=='Y=longitudinal; X,Z=cross-section'||a.Object.units!=='normalized-design-demo-not-measured')throw Error('Unsupported local coordinate contract');
 const p=a.Object.parameters,keys=['profile','length','width','depth','rounding','damage','grainDensity','exposure','finish','jointWidth','jointHeight','clearance','seed','knotStyle','crackStyle'];if(Object.keys(p).some(k=>!keys.includes(k)))throw Error('Unsupported reference parameter');for(const k of keys)if(!Number.isFinite(p[k]))throw Error('Nonfinite '+k);
 if(!Number.isInteger(p.knotStyle)||p.knotStyle<0||p.knotStyle>2||!Number.isInteger(p.crackStyle)||p.crackStyle<0||p.crackStyle>2)throw Error('Unsupported knot or crack style');
 if(p.exposure<0||p.exposure>1||p.finish<0||p.finish>1||!Number.isSafeInteger(p.seed)||p.seed<0||p.seed>65535)throw Error('Unsupported material domain');
 if(p.length<1.8||p.length>4||p.width<.4||p.width>.9||p.depth<.4||p.depth>.9||p.rounding<0||p.rounding>Math.min(p.width,p.depth)/4||p.damage<0||p.damage>1||p.grainDensity<.5||p.grainDensity>2||p.jointWidth<=0||p.jointWidth>p.depth*.7||p.jointHeight<=0||p.jointHeight>p.width*.7||p.clearance<0||p.clearance>.04)throw Error('Reference parameter outside supported domain');
 if(!['forms','comparison','focus'].includes(a.Object.studyView)||!Number.isInteger(p.profile)||p.profile<0||p.profile>8)throw Error('Unsupported study/profile');
 const recipe=a.Object.materialRecipe;if(!recipe||recipe.version!==MATERIAL_SEED_VERSION||!['identity','shared'].includes(recipe.mode)||!recipe.overrides||Array.isArray(recipe.overrides)||Object.keys(recipe).some(k=>!['version','mode','overrides'].includes(k)))throw Error('Unsupported material seed recipe');
 for(const v of Object.values(recipe.overrides))if(!Number.isSafeInteger(v)||v<0||v>4294967295)throw Error('Invalid explicit material seed');
 const I=[[1,0,0],[0,1,0],[0,0,1]],Z=[[1,0,0],[0,0,-1],[0,1,0]],X=[[0,1,0],[-1,0,0],[0,0,1]];
 const records=[], common={length:p.length,width:p.width,depth:p.depth,rounding:p.rounding};
 const add=(id,kind,center,rotation,spec={},parent='wood-reference-study')=>records.push({id,parent,mother:'WOOD-SHAPE-R01',spec:{...common,kind,...spec},placement:{center,rotation},material:{profile:p.profile,version:'WOOD-PROFILES-R01',seedBase:p.seed,seedRecipe:recipe.version,seedSource:Object.hasOwn(recipe.overrides,id)?'explicit-override':recipe.mode,seed:Object.hasOwn(recipe.overrides,id)?recipe.overrides[id]:(recipe.mode==='shared'?p.seed:materialSeed(p.seed,id)),grainDensity:p.grainDensity,exposure:p.exposure,finish:p.finish,damage:p.damage,knotStyle:p.knotStyle}});
 // All placements below are display staging; physical site Location remains unknown.
 add('round-log','cylinder',[-2.5,p.length/2,0],I,{radius:p.width*.66});
 add('square-beam','box',[-1.4,p.depth/2,1.25],Z);
 add('grooved-log','cylinder',[-.15,p.width*.6,1.45],Z,{radius:p.width*.6,slots:[{center:[0,0,-p.width*.5],size:[p.width*.31,p.length+.02,p.width*.45]}]});
 add('tenoned-beam','box',[1.2,p.depth/2,1.35],Z,{tenons:[{center:[0,p.length/2+.14,0],size:[p.width*.45,.30,p.depth*.45]}]});
 const span=2.5,postX=1.35,postZ=-1.1,postH=p.length+.45,crossY=postH*.72,beamLen=span-p.width,jw=p.jointWidth,jh=p.jointHeight,clear=p.clearance;
 const joint={width:jw,height:jh,clearance:clear,span,axis:'world-X',worldY:crossY};
 for(const sign of [-1,1])add(sign<0?'frame-left':'frame-right','box',[postX+sign*span/2,postH/2,postZ],I,{length:postH,mortises:[{center:[0,crossY-postH/2,0],size:[p.width+.04,jh+2*clear,jw+2*clear]}]},'mortise-tenon-frame');
 add('frame-crossbeam','box',[postX,crossY,postZ],X,{length:beamLen,width:p.width,depth:p.depth,tenons:[-1,1].map(s=>({center:[0,s*(beamLen/2+p.width*.55),0],size:[jh,p.width*1.12,jw]}))},'mortise-tenon-frame');
 if(a.Object.studyView!=='forms'){records.length=0;for(const profile of a.Object.studyView==='comparison'?[0,1,2,3,4,5,6,7]:[p.profile]){add('sample-'+profile,'box',[0,p.length*.72/2,0],I,{length:p.length*.72,width:p.width*1.7,depth:p.depth});const m=records[records.length-1].material;m.profile=profile;if(!Object.hasOwn(recipe.overrides,'sample-'+profile)){m.seed=recipe.mode==='shared'?p.seed:materialSeed(p.seed,'comparison-specimen');m.seedSource='shared-comparison-specimen';}}}
 if(Object.keys(recipe.overrides).some(id=>!records.some(r=>r.id===id)))throw Error('Material override names unknown instance');
 return {version:VERSION,parameters:{...p},records,assemblies:a.Object.studyView==='forms'?[{id:'mortise-tenon-frame',parent:'wood-reference-study',joint}]:[],evidence:{actualDimensions:null,scale:'normalized-design-demo',physicalPlacement:null},source:a};
}
const api={VERSION,MATERIAL_SEED_VERSION,materialSeed,source,expand};if(typeof module!=='undefined')module.exports=api;root.WoodReferenceAuthority=api;
})(typeof globalThis!=='undefined'?globalThis:this);

(function(root){
'use strict';
const A=typeof require==='function'?require('./authority.js'):root.WoodReferenceAuthority,G=typeof require==='function'?require('../reference-shapes-lane/geometry.js'):root.WoodShapes;
const dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2],add=(a,b)=>[a[0]+b[0],a[1]+b[1],a[2]+b[2]],sub=(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]],mul=(a,b)=>[a[0]*b,a[1]*b,a[2]*b],mat=(m,v)=>[dot(m[0],v),dot(m[1],v),dot(m[2],v)],inv=(m,v)=>[m[0][0]*v[0]+m[1][0]*v[1]+m[2][0]*v[2],m[0][1]*v[0]+m[1][1]*v[1]+m[2][1]*v[2],m[0][2]*v[0]+m[1][2]*v[1]+m[2][2]*v[2]];
function compile(authority){
 const data=A.expand(authority),records=data.records.map(r=>{
 const spec=G.withBoundaryDamage(JSON.parse(JSON.stringify(r.spec)),r.parent==='mortise-tenon-frame'?0:data.parameters.damage,data.parameters.seed);
 const checked=G.withWoodChecks(spec,r.parent==='mortise-tenon-frame'?0:data.parameters.damage,data.parameters.seed,data.parameters.crackStyle);const shape=G.compileShape(checked),m=r.placement.rotation,c=r.placement.center;
 const corners=[];for(const x of [shape.bounds.min[0],shape.bounds.max[0]])for(const y of [shape.bounds.min[1],shape.bounds.max[1]])for(const z of [shape.bounds.min[2],shape.bounds.max[2]])corners.push(add(c,mat(m,[x,y,z])));
 return {...r,compiledSpec:checked,shape,bounds:{min:[0,1,2].map(i=>Math.min(...corners.map(p=>p[i]))),max:[0,1,2].map(i=>Math.max(...corners.map(p=>p[i])))}};
 });
 function bound(o,d,b,maxT){let lo=0,hi=maxT;for(let i=0;i<3;i++){if(Math.abs(d[i])<1e-14){if(o[i]<b.min[i]||o[i]>b.max[i])return false;continue}const a=(b.min[i]-o[i])/d[i],c=(b.max[i]-o[i])/d[i];lo=Math.max(lo,Math.min(a,c));hi=Math.min(hi,Math.max(a,c));if(hi<lo)return false}return true}
 function hit(o,d,maxT=Infinity,tMin=1e-5){let best=null;for(const r of records){if(!bound(o,d,r.bounds,best?best.t:maxT))continue;const m=r.placement.rotation,h=r.shape.hit(inv(m,sub(o,r.placement.center)),inv(m,d),tMin);if(h&&h.t<maxT&&(!best||h.t<best.t))best={...h,localP:h.p,localN:h.n,p:add(r.placement.center,mat(m,h.p)),n:mat(m,h.n),record:r};}return best}
 function occluded(o,d,maxT=Infinity){for(const r of records){if(!bound(o,d,r.bounds,maxT))continue;const m=r.placement.rotation;if(r.shape.occluded(inv(m,sub(o,r.placement.center)),inv(m,d),maxT,1e-5))return true}return false}
 return {data,records,hit,occluded};
}
const api={compile,mat,inv,add,sub,mul,dot};if(typeof module!=='undefined')module.exports=api;root.WoodReferenceScene=api;
})(typeof globalThis!=='undefined'?globalThis:this);

# KAOPU Wood Mother V28

固定公网预览：https://kaopu-wood-mother-r01.sunhaihao.chatgpt.site/v28

本包包含Wood Mother的现有材质与对象函数、旧油饰木profile 8、七构件演示工作台、标志与MIT许可，不包含原始参考图片、图纸或模型。请先读wood-functions/README.md；它的版本叙述以本说明为准。代码版本：bead4b79993856bbd515dae48f6cf191d12f2ab1。材质是程序化视觉效果，不是实测树种或真实老化模型，示例构件不是具体建筑实测。

运行 `node wood-functions/verify-handoff.cjs` 可检查入口。V28最高缩放250%；新样式和缩放仍需宿主与目标设备核验。

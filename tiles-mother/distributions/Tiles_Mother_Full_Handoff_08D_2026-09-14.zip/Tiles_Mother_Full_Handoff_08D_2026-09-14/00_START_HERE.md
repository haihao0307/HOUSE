# Tiles Mother 08D 全量交接

当前版本为 08D。用户已确认“非常好，基本上成功了”，剩余一点微调转到其他工作台处理。本次交接冻结现有成果，不新增外观改动。用户完整评价见 USER_ACCEPTANCE.json。

公网预览：https://raw.githack.com/haihao0307/HOUSE/d3f5a1fc7683daf9838f67957e55b549319a92ef/tiles-mother/r2-closeout-08d-relief/START_HERE.html

## 接手入口

- project/current-08D/START_HERE.html：自包含工作台。
- project/current-08D/build.py：使用同目录 base-08C1.html、shape.glsl 构建当前 HTML，需 Python 3 和 Node.js（语法检查）。
- project/current-08D/qa_geometry.cjs 与 contact-lib.cjs：可直接运行 Node 复查代表接触，CONTACT_QA.json 保存现有失败结果。脚本正常退出不意味着接触通过，必须检查 contactPassed。
- knowledge/：Microscope 教学、讲武堂轻量分析和来源凭据。
- reference/：用户本轮提供的形态截图，仅作外观参考；不作为物理测量。
- rules/：共同规则原件和历史 Tiles 规则。历史分支名与旧任务指令不覆盖本次来源锁及最新用户要求。

## 已实现与边界

Microscope 已进入瓦面起伏、边口轮廓和有底气孔的真实几何。默认形态强度 1.6，PBR 独立。几何、灰模、桌面公网交互和390×844布局检查已执行，具体范围见 QA.json 和项目 README。

用户对当前视觉成果已作基本成功评价；历史 QA 中 visualApproved=false 是用户本次评价之前的状态，不应误读为未收到评价。仍有少量视觉微调由其他工作台继续；用户并未批准整屋工程生产。

原有屋面两处接触失败仍存在：约0.5223mm与0.3097mm，不能写成通过。本轮默认代表接触在关闭、默认、增强三档没有进一步恶化，不代表所有种子、所有对象或全状态证明。原始讲武堂大 FBX/贴图包由用户保管，未纳入本轻量全量交接；本包包含其凭据和分析。

## 后续规则

后续可按用户要求迁移到其他工作台；保留对象身份、局部参考架、尺寸与连接约束，以及当前成果的固定版本来源。不能恢复撤销技能或失败路线。几何显示缓冲不是对象知识。新预览仍需固定版本公网 HTTPS，旧链接不覆盖。

SHA256SUMS.txt 覆盖全部有效载荷文件，PACKAGE_RECEIPT.json 位于 ZIP 外记录整包哈希。

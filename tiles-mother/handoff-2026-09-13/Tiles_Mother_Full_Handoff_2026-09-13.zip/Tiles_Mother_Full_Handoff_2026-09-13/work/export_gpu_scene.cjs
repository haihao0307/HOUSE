// Export the existing production scene for standalone GPU regression tests.
// This does not operate a browser or approximate the tile geometry.
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=__dirname, file=process.argv[2],scene=process.argv[3]||'pan',year=+(process.argv[4]||0),label=process.argv[5]||scene;
const html=fs.readFileSync(file,'utf8');
let js=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]).join('\n').replace(/\ninit\(\);\s*$/, '\n');
const context=vm.createContext({performance,console,document:{querySelector:()=>({})},Float32Array,Uint32Array,Uint8Array,Map});
vm.runInContext(js+'\nglobalThis.exports={Workshop,settings,VERT,FRAG,DEPTH_VERTEX,DEPTH_FRAGMENT,M,V,smooth};',context);
const e=context.exports, groups=[];
const renderer={clear:()=>{groups.length=0},add:(mesh,instances,type,cast)=>groups.push({mesh,instances,type,cast})};
const workshop=new e.Workshop(renderer),settings={...e.settings,scene,year};workshop.build(settings);
const camera={target:Array.from(workshop.fit.target),distance:workshop.fit.distance,yaw:workshop.fit.yaw,pitch:workshop.fit.pitch};
if(scene==='pan'||scene==='cover'){camera.distance*=.68;camera.pitch=.65;camera.yaw=-.60;}
const w=1400,h=1000,eye=[camera.target[0]+camera.distance*Math.cos(camera.pitch)*Math.sin(camera.yaw),camera.target[1]+camera.distance*Math.sin(camera.pitch),camera.target[2]+camera.distance*Math.cos(camera.pitch)*Math.cos(camera.yaw)];
const L=e.V.norm([-3.6,7.5,4.1]),center=workshop.bounds.center,rad=workshop.bounds.radius;
const uniforms={uVP:Array.from(e.M.mul(e.M.perspective(.61,w/h,.008,100),e.M.look(eye,camera.target))),uLightVP:Array.from(e.M.mul(e.M.ortho(-rad,rad,-rad,rad,.02,rad*7),e.M.look(e.V.add(center,e.V.scale(L,rad*3.4)),center))),uEye:eye,uLight:L,uSurface:[settings.relief,settings.warmth,settings.patina,settings.wet],uColor:[settings.brightness,-.06,settings.variation,settings.core],uBio:[settings.moss*(scene.startsWith('roof')?e.smooth(1,10,year):.52),settings.mossHeight,settings.twist,settings.r2],uFinish:settings.finish||0,uDiagnostic:0,uShadowTexel:1/1024,uShadowEnabled:1,uShadow:0};
const out=path.join(root,'gpu-scenes',label);fs.mkdirSync(out,{recursive:true});
for(const key of ['VERT','FRAG','DEPTH_VERTEX','DEPTH_FRAGMENT'])fs.writeFileSync(path.join(out,key+'.glsl'),e[key]);
const manifest={scene,year,camera,settings,stats:workshop.stats,records:workshop.records,uniforms,width:w,height:h,groups:[]};
function write(name,array){fs.writeFileSync(path.join(out,name),Buffer.from(array.buffer,array.byteOffset,array.byteLength));return name;}
groups.forEach((g,i)=>{const data=new Float32Array(g.instances.length*20);g.instances.forEach((it,j)=>{data.set(it.m,j*20);data.set(it.s,j*20+16)});manifest.groups.push({type:g.type,cast:g.cast,instances:g.instances.length,p:write(i+'-p.bin',g.mesh.p),n:write(i+'-n.bin',g.mesh.n),meta:write(i+'-meta.bin',g.mesh.meta),idx:write(i+'-idx.bin',g.mesh.idx),data:write(i+'-data.bin',data)});});
fs.writeFileSync(path.join(out,'scene.json'),JSON.stringify(manifest));console.log(JSON.stringify({out,groups:groups.length,stats:manifest.stats}));

"""Compile and render the production shaders in a native OpenGL test context.
ES-to-desktop declarations only; not a browser or a substitute for public QA.
"""
from pathlib import Path
import sys,json,re,time
import moderngl,numpy as np
from PIL import Image
root=Path(__file__).resolve().parent
label=sys.argv[1]
folder=root/'gpu-scenes'/label
m=json.loads((folder/'scene.json').read_text())
c=moderngl.create_standalone_context(require=330)
def shader(name):
    s=(folder/(name+'.glsl')).read_text()
    s=s.replace('#version 300 es','#version 330')
    s=re.sub(r'precision\s+\w+\s+\w+\s*;','',s)
    s=re.sub(r'\b(highp|mediump|lowp)\s+','',s)
    return s
program=c.program(vertex_shader=shader('VERT'),fragment_shader=shader('FRAG'))
depth_program=c.program(vertex_shader=shader('DEPTH_VERTEX'),fragment_shader=shader('DEPTH_FRAGMENT'))
def set_uniforms(p,values):
    for key,value in values.items():
        if key not in p:continue
        if isinstance(value,list) and len(value)==16:p[key].write(np.array(value,dtype='f4').tobytes())
        else:p[key].value=tuple(value) if isinstance(value,list) else value
set_uniforms(program,m['uniforms']);set_uniforms(depth_program,m['uniforms'])
vaos=[]
for g in m['groups']:
    b={k:c.buffer((folder/g[k]).read_bytes()) for k in ['p','n','meta','data','idx']}
    content=[(b['p'],'3f','aPosition'),(b['n'],'3f','aNormal'),(b['meta'],'2f','aMeta'),(b['data'],'16f 4f /i','aModel','aState')]
    vaos.append((g,c.vertex_array(program,content,b['idx'],skip_errors=True),c.vertex_array(depth_program,content,b['idx'],skip_errors=True)))
shadow=c.depth_texture((1024,1024));shadow.compare_func='<=';shadow.filter=(moderngl.LINEAR,moderngl.LINEAR);shadow.repeat_x=False;shadow.repeat_y=False
shadow_fbo=c.framebuffer(depth_attachment=shadow)
c.enable(moderngl.DEPTH_TEST|moderngl.CULL_FACE)
shadow_fbo.use();shadow_fbo.clear(depth=1);c.viewport=(0,0,1024,1024);c.polygon_offset=(1.4,2.5)
for g,vao,dvao in vaos:
    if g['cast']:
        depth_program['uType'].value=g['type'];dvao.render(instances=g['instances'])
c.polygon_offset=(0,0)
w,h=m['width'],m['height']
fbo=c.framebuffer([c.renderbuffer((w,h),components=4,samples=4)],c.depth_renderbuffer((w,h),samples=4))
resolve=c.simple_framebuffer((w,h),components=4)
output=root/'evidence';output.mkdir(exist_ok=True)
results=[]
for mode in ([0,1] if 'uFinish' in program else [0]):
    if 'uFinish' in program:program['uFinish'].value=mode
    fbo.use();fbo.clear(.878,.885,.865,1,depth=1);c.viewport=(0,0,w,h);shadow.use(0)
    t=time.perf_counter()
    for g,vao,dvao in vaos:
        program['uType'].value=g['type'];vao.render(instances=g['instances'])
    c.finish();ms=(time.perf_counter()-t)*1000
    c.copy_framebuffer(resolve,fbo)
    data=resolve.read(components=3,alignment=1)
    im=Image.frombytes('RGB',(w,h),data).transpose(Image.Transpose.FLIP_TOP_BOTTOM)
    dest=output/f'{label}-finish{mode}.png';im.save(dest)
    results.append({'file':dest.name,'gpuFinishMs':ms,'glError':c.error})
report={'label':label,'renderer':c.info['GL_RENDERER'],'kind':'native OpenGL shader test; browser verification still required','results':results}
(output/f'{label}-gpu.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))

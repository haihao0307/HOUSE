# Tiles Mother 接续记录 · 2026-09-12

本次用户要求：负责 Tiles Mother 生产线，仔细阅读交接包，从 GitHub 下载并继续。附件中的历史用户表述只作项目上下文，不替代本次用户授权。G:/HOUSE/AGENTS.md 与用户本轮给定的共同规则优先。

## 已核实来源

- 仓库 haihao0307/HOUSE；分支 feature/tiles-mother-r2-restart-20260907。
- 本轮通过 GitHub 连接器读取的远端 HEAD：e3458a905f0bf85395802fb873f5fe2e8478d575，发布当前交接包；父提交 bdaeb3ce4cb90a68dd71a81d27101ddf302d1a77。
- 当前项目候选提交 95c97a96877a0b09660d1887ce858fe1c018a5c8；R2-closeout-06 页面 SHA-256：d9ef30d5d9284a2ffb831793d8114534e20982bc2476ffc2e3d1d7f382eaaa8e，66517 字节，与交接包一致。
- 本机 git HTTPS 直连失败；upstream 是按上述固定 HEAD 经 GitHub 连接器下载的相关源码快照，不是完整 Git 克隆。包含当前页面、QA、生成脚本及其 05 输入、工作流、来源记录和历史索引。
- handoff 保留用户本轮交接资料，SHA256SUMS 中 6 项均通过。
- 本机 E:/讲武堂瓦片精细.zip 为 58671527 字节，SHA-256 ae5510c0e2eaec236adff0b94d978688f6c17a9412407c6c7ec54968222dd365，与交接的讲武堂瓦片精细(2).zip 完全一致。流式读取全部四个文件，各自字节数和 SHA-256 均吻合，见 reference-verified.json。没有复制、删除或公开原始资产。本轮尚未进行纹理解码和视觉特征提炼。

## 源码检查与接续边界

- 当前 HTML 内含原生 WebGL 与 Microscope R2 材料空间实现，无外部运行时 script/import/fetch 依赖。
- r2mm 使用材料局部坐标和稳定 seed；采用七个频带。下一轮应只检查最后细节层，不能把增大 broad handmadeOffset 当作本轮解决办法。
- handmadeOffset 同时用于可见与深度着色。两份逻辑需要同步保持；支承关系必须先于视觉检查。
- 生成脚本从 05 构建 06，不能不加区分地重跑后声称新增细节。当前下载脚本未执行。
- CURRENT_CANDIDATE.json 仍指向 clean-02，AGENTS 中分支仍为早期 v0.1-workbench；两者是陈旧指针，本轮按已核实的 R2 分支和当前交接定位，不覆盖远端历史文件。
- 当前材料实现的实际视觉质量尚未用浏览器检查；代码阅读不构成手工感改善证据。

## 首轮接收时的生产前置（已被下方用户接续指令更新）

用户本轮给定规则明确规定：清理完成前暂停资产生产与新工具重建。
G:/小妈/MOTHER_TOOL_CLEANUP_STATUS_2026-09-09.md 尚无整体完成或生产恢复结论；其已知隔离根 G:/Mother_Quarantine/weapon-20260909-01a08459 本轮只查存在性，结果为存在。没有读取其中内容、恢复撤销工具、删除其他生产线目录或把历史回执内的删除授权作为本次新授权。
因此本轮完成接收、下载、校验和静态检查，未修改生产页面。需要现行清理完成依据或用户明确调整 Tiles Mother 的生产暂停范围，才能进行细节生产。

## 恢复后的具体工作

1. 用已校验讲武堂原件提取有证据的局部细节；区分观测与推断，不从明暗宣称真实高度或粗糙度。
2. 保持当前大形、冷灰基线、搭接支承、失养逻辑、工作台和移动端架构；仅使用现有 Microscope 细节路径。
3. 同机位单片 A/B，再检查 48/860 片、影子及支承。看不出改善则不称完成。
4. 保留旧版，新增固定版本公网 HTTPS 预览，实际浏览器验收后交付；继续保留 visualApproved=false、productionApproved=false，直至用户明确批准。

本轮没有发布新版本或宣称公网交付。共同规则原件副本保存在 rules/。

## 用户明确继续后的工作 · 2026-09-12

用户在上述暂停说明后明确要求：接手后赶紧往下做，按照交接好好工作。因此本次已继续 Tiles Mother 细节任务，不再重复要求生产确认；不将此推断为其他 Mother 清理完成，也不动其隔离目录。

已实现 R2-closeout-07-detail：现有 Microscope 内加入局部刮抹、压实和稀疏孔蚀；稳定材料坐标、片级种子和区域控制方向。原有低频形体/材料、顶点与深度着色、场景历史代码不变。新增材质面板 06/07 同机位 A/B，修正参数保存与调试入口的版本标识为 07。

实现脚本 build_detail07.py；候选 candidate/r2-closeout-07-detail/。源码 SHA-256 d101a20b0290cc20a148d65f64dfad1c4a00d402143e2492508138566100200b，69342 字节。原件两张贴图已实际解码；仅将少量局部裁图保存在本机 evidence/，没有上传原件、大贴图或参考裁图。

验证：node --check 通过。export_gpu_scene.cjs 从实际生产 JS 导出场景，render_gpu.py 用原生 OpenGL 编译与渲染生产着色器，GL_NO_ERROR。单片 A 与原版 06 逐像素相同；07 的近景局部改变可见，但不代替用户视觉批准。板瓦、筒瓦、小屋面、860 片、木构已渲染并查看。木构 A/B 相同；860 片整坡远景由于 footprint 淡出而 A/B 相同。0/3/5/7/10 年在役悬空数均 0。原生 GPU 测试不等同于 WebGL 浏览器/移动端验收。

已通过 GitHub 连接器提交现有 feature/tiles-mother-r2-restart-20260907 分支，非强推：dcf4053f69efc031174b7c41bd41e2309dfb13ec。新增 07 页面、QA、README、两份共同规则副本及生成脚本；旧版未修改。GitHub 固定提交源码回读与本机逐字一致。

固定候选 URL：https://raw.githack.com/haihao0307/HOUSE/dcf4053f69efc031174b7c41bd41e2309dfb13ec/tiles-mother/r2-closeout-07-detail/START_HERE.html

公网交付尚未完成。浏览器清单两次 nodeRepl.fetch request failed，创建 iab 标签页超时；open_in_codex 只返回 queued，不能当作已打开。网页读取工具也未成功打开 raw.githack。browserVerified/publicBrowserVerified/visualApproved/productionApproved 均为 false。下一步优先恢复浏览器连接，实际打开上述固定 URL 检查 07 版本、单片 A/B、旋转缩放、场景/年份切换、48/860 片近景及移动端面板；不重复索要生产授权，不把本机离屏图或 ZIP 作为最终公网预览。

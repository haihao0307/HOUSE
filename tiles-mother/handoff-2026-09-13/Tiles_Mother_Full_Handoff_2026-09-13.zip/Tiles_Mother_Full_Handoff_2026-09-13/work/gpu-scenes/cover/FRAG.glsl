#version 300 es
precision highp float;
precision highp int;
in vec3 vWorld,vLocal,vNormal;
in vec4 vShadow;
in vec2 vMeta;
flat in vec4 vState;
uniform vec3 uEye,uLight;
uniform vec4 uSurface,uColor,uBio;
uniform int uType,uDiagnostic;
uniform float uShadowTexel,uShadowEnabled,uFinish;
uniform highp sampler2DShadow uShadow;
out vec4 fragColor;
uint hashU(ivec3 p){uvec3 a=uvec3(p);uint h=a.x*1597334677u^a.y*3812015801u^a.z*2798796415u;h^=h>>16;h*=2146121005u;h^=h>>15;h*=2221713035u;h^=h>>16;return h;}
vec3 gradient(ivec3 i){uint h=hashU(i)%12u;float a=(h&1u)==0u?1.:-1.,b=(h&2u)==0u?1.:-1.;return h<4u?vec3(a,b,0):h<8u?vec3(a,0,b):vec3(0,a,b);}
float corner(vec3 x,ivec3 i){float w=max(.6-dot(x,x),0.);w*=w;return w*w*dot(gradient(i),x);}
// Tetrahedral gradient field avoids axis-aligned value-cell patches.
float n3(vec3 p){vec3 ii=floor(p+dot(p,vec3(1./3.))),x=p-ii+dot(ii,vec3(1./6.));
 vec3 g=step(x.yzx,x.xyz),l=1.-g,i1=min(g,l.zxy),i2=max(g,l.zxy);
 ivec3 i=ivec3(ii);
 float n=corner(x,i)+corner(x-i1+1./6.,i+ivec3(i1))+corner(x-i2+1./3.,i+ivec3(i2))+corner(x-.5,i+ivec3(1));
 return clamp(.5+16.*n,0.,1.);}
// Film footprint gates only displayed frequencies, never object geometry/history.
float band(float footprint,float scale){return 1.-smoothstep(.35,.95,footprint*scale);}
mat2 rot2(float a){float c=cos(a),s=sin(a);return mat2(c,-s,s,c);}
// One fixed rotation would only change the reference frame. Independent meaning
// begins when orientation varies smoothly with stable material regions/position.
float ceramicTurn(vec3 p,float seed){
 vec3 z=p+vec3(seed*.0017,seed*.0023,seed*.0011);
 float mineral=n3(z*5.4+vec3(2.7,8.1,4.3));
 float local=n3(z*17.6+vec3(9.2,1.4,6.8));
 float tilePhase=sin(seed*.031+1.7)*.5+.5;
 return (tilePhase-.5)*.10+(mineral-.5)*.30+(local-.5)*.085;
}
// Domain warp is deliberately low-amplitude and tied to stable material coordinates.
// It breaks periodic alignment without changing tile geometry or support relationships.
vec3 ceramicWarp(vec3 p,float seed){
 vec2 x=p.xz;
 float a=seed*.0137;
 vec2 d1=vec2(cos(a),sin(a)),d2=vec2(cos(a*1.71+1.1),sin(a*1.71+1.1));
 float u=dot(x,d1),v=dot(x,d2);
 float w1=sin(u*13.0+1.05*sin(v*8.0+a));
 float w2=sin(v*17.0+.72*sin(u*10.0-a*.63));
 x+=d2*(w1*.0027)+d1*(w2*.0016);
 p.x=x.x;p.z=x.y;return p;
}
// Broad colony -> broken rim -> sparse pore logic. It is not uniform pepper noise.
float ceramicColony(vec3 p,float seed){
 vec2 x=p.xz;
 float a=seed*.0173;
 vec2 d1=vec2(cos(a),sin(a)),d2=vec2(cos(a*1.83+1.7),sin(a*1.83+1.7));
 float u=dot(x,d1),v=dot(x,d2);
 float broad=.5+.5*sin(u*18.0+1.35*sin(v*11.0+a)+.33*sin((u+v)*7.0-a));
 float middle=.5+.5*sin(v*43.0+1.05*sin(u*29.0-a*.7)+.41*sin((u-v)*21.0+a));
 float rim=.5+.5*sin(u*83.0+v*67.0+1.25*sin(v*31.0+a));
 float island=smoothstep(.45,.73,broad*.66+middle*.34);
 return clamp(island*(.64+.36*smoothstep(.38,.72,rim)),0.,1.);
}
float tileIdentity(float seed){return fract(sin(seed*12.9898+78.233)*43758.5453);}
float ceramicWave(vec3 p,float seed,float scale){
 vec2 x=p.xz;float a=seed*.0119;
 vec2 d1=vec2(cos(a),sin(a)),d2=vec2(cos(a*1.57+2.1),sin(a*1.57+2.1));
 float u=dot(x,d1),v=dot(x,d2);
 float f=.56*sin(u*scale+a)+.31*sin(v*scale*.67+1.08*sin(u*scale*.31-a))+.13*sin((u-v)*scale*.43+a*.7);
 return clamp(.5+.5*f,0.,1.);
}

// Macroscopic microscope R2 is used here only as a stable, material-space
// cross-scale microstructure. It never defines the tile outline or roof seating.
float r2mm(vec3 p,float seed,float footprint){
 vec3 o=.013*vec3(sin(seed*.17),cos(seed*.11),sin(seed*.07));
 vec3 d=p-o;float rr=max(length(d*vec3(1.,3.5,1.)),.002);
 vec3 m=vec3(log2(1.+rr*24.),atan(d.z,d.x),d.y*36.);
 float sum=0.,amp=.5,sc=1.;
 // Seven band-limited scales preserve the coarse prefix and make the R2
 // normal response legible without changing the shell or seating geometry.
 for(int i=0;i<7;i++){
   float gate=band(footprint,70.*sc);
   float C0=cos(cos(m.z*sc)*cos(m.x*sc)+cos(m.y*sc)*cos(m.y*sc)+cos(m.y*sc)*cos(m.x*sc));
   float C1=cos(cos((m.z+.37)*sc*.73)*cos((m.x-.21)*sc*1.17)+cos((m.y+.19)*sc*.81)*cos((m.y+.19)*sc*.81)+cos((m.y+.19)*sc*.81)*cos((m.x-.21)*sc*1.17));
   sum+=amp*mix(C0,C1,.32)*gate;amp*=.5;sc*=2.;
 }
 return sum;
}
// R2 final-detail layer. All coordinates are tile-local; seeds and slowly
// varying material regions control direction. These display-relief amplitudes
// are design parameters, NOT physical measurements from the reference texture.
// Original r2mm and all low-frequency body/geometry fields remain unchanged.
vec4 r2Finish(vec3 p,float seed,float footprint){
 float visible=band(footprint,460.);
 if(visible<=0.)return vec4(0.);
 float identity=tileIdentity(seed+131.);
 vec3 offset=vec3(identity*17.3,seed*.037,identity*9.7);
 float region=n3(p*33.7+offset+vec3(2.1,7.8,4.2));
 float turn=(identity-.5)*1.7+ceramicTurn(p,seed)*2.1+(region-.5)*.42;
 vec2 directed=rot2(turn)*p.xz;
 vec3 q=vec3(directed.x,p.y,directed.y);
 q.x+=(n3(p*61.3+offset+vec3(7.3,1.1,5.2))-.5)*.0026;
 // Finite, interrupted strokes: no repeated sinusoidal ridges or dot lattice.
 float pressure=n3(q*vec3(41.,67.,32.)+offset);
 float strokeField=n3(q*vec3(571.,217.,47.)+offset+vec3(3.1,9.4,2.7));
 float strokeGate=smoothstep(.53,.78,pressure);
 float groove=smoothstep(.60,.82,strokeField)*strokeGate*band(footprint,640.);
 float shoulder=(smoothstep(.41,.59,strokeField)-smoothstep(.59,.76,strokeField))*strokeGate*band(footprint,640.);
 // Pores concentrate in broken patches; compacted zones remain quieter.
 float patch=n3(p*89.3+offset+vec3(5.7,1.3,8.1));
 float grain=n3(q*733.7+offset+vec3(9.7,3.2,6.3));
 float pore=smoothstep(.70,.88,grain)*smoothstep(.43,.74,patch)*(1.-.65*strokeGate)*band(footprint,820.);
 float pressed=(n3(q*vec3(167.,109.,113.)+offset+vec3(8.1,6.7,1.3))-.5)*strokeGate;
 float relief=(pressed*.00038-groove*.00062+shoulder*.00014-pore*.00048)*visible;
 // Independent roughness field, conditioned on the forming structure, never RGB.
 float roughField=n3(p*211.3+offset+vec3(19.1,4.3,13.7))-.5;
 float roughDelta=(roughField*.042-groove*.055+pore*.070)*visible;
 return vec4(relief,groove*visible,pore*visible,roughDelta);
}
vec3 srgb(vec3 c){c=max(c,vec3(0));return mix(c*12.92,1.055*pow(c,vec3(1./2.4))-.055,step(vec3(.0031308),c));}
vec3 perturb(vec3 N,vec3 p,float height){
 vec3 dx=dFdx(p),dy=dFdy(p),r1=cross(dy,N),r2=cross(N,dx);
 float det=dot(dx,r1);vec3 g=sign(det)*(dFdx(height)*r1+dFdy(height)*r2);
 return normalize(abs(det)*N-g);
}
float segdist(vec2 p,vec2 a,vec2 b){vec2 d=b-a;return length(p-a-d*clamp(dot(p-a,d)/max(dot(d,d),1e-8),0.,1.));}
float ceramicCrack(vec2 p,float seed,float damage,float footprint){
 if(damage<.11)return 0.;
 float x=p.x,z=p.y;
 float path=.012*sin(x*87.+seed)+.004*sin(x*231.+seed*.7)+.036*x;
 float width=mix(.00007,.00042,damage),aa=max(footprint*.70,.000035);
 float gate=1.-smoothstep(.050,.105,abs(x-(seed-.5)*.055));
 float crack=1.-smoothstep(width,width+aa,abs(z-path));
 float branch=segdist(p,vec2(.02,path),vec2(.065,path+.028));
 return max(crack*gate,(1.-smoothstep(width*.7,width+aa,branch))*.7)*smoothstep(.11,.47,damage);
}
void main(){
 vec3 N=normalize(vNormal);if(!gl_FrontFacing)N=-N;
 vec3 p=vLocal;
 float seed=vState.x,damage=vState.y,tint=vState.z;
 float fp=max(length(dFdx(p)),length(dFdy(p)));
 vec3 base;float rough=.86,height=0.,ao=1.;
 vec3 q=p+vec3(seed*.017,seed*.023,seed*.019);
 // Stable orientation field: ceramic direction follows tile/mineral/local regions.
 // No view vector or world camera participates, and no stack of redundant fixed rotations remains.
 if(uType==1){float turn=uBio.z*.37*sin(p.z*11.0+seed*.17);q.xy=rot2(turn)*p.xy+vec2(seed*.017,seed*.023);}
 else if(uType==0){float turn=uBio.z*ceramicTurn(p,seed);q.xz=rot2(turn)*p.xz+vec2(seed*.017,seed*.019);q=ceramicWarp(q,seed);}
 float macro=.5,middle=.5;
 if(uType!=3){macro=n3(q*17.3);middle=mix(.5,n3(q*63.7+vec3(8.1,1.7,3.8)),band(fp,63.7));} if(uType==0){macro=ceramicWave(q,seed+11.,17.0);middle=mix(.5,ceramicWave(q,seed+29.,57.0),band(fp,57.0));}
 if(uType==0){
   float fired=ceramicWave(q,seed+47.,8.5);
   float weather=clamp(uSurface.z,0.,1.);
   float grain=.5,micro=.5;
   if(fp*390.<.95)grain=mix(.5,n3(q*390.1),band(fp,390.));
   if(fp*1167.<.95)micro=mix(.5,n3(q*1167.),band(fp,1167.));

   // Substance-like ordering adapted to ceramic: structure first.
   float tileId=tileIdentity(seed);
   float colony=ceramicColony(q,seed);
   float scrape=smoothstep(.66,.86,n3(vec3(q.x*731.,q.y*337.,q.z*71.)+vec3(tileId*5.3,1.7,6.2)))*smoothstep(.48,.70,middle)*band(fp,760.);
   float pitThreshold=mix(.79,.88,tileId);
   float sparsePit=smoothstep(pitThreshold-.045,pitThreshold+.055,grain)*band(fp,390.);
   float pit=sparsePit*mix(.16,1.0,smoothstep(.20,.72,colony));
   float r2Gate=mix(.24,.82,smoothstep(.18,.78,colony));
   float r2detail=r2mm(q,seed+tileId*37.0,fp)*uBio.w*r2Gate;
   float crack=ceramicCrack(p.xz,fract(seed*.73),damage,fp);
   float skin=smoothstep(.05,.92,vMeta.x);
   float shellEdge=1.-smoothstep(.76,.985,vMeta.x);
   float structuralHeight=(middle-.5)*.00018+(grain-.5)*.00012*band(fp,390.)+(micro-.5)*.000047*band(fp,1167.)+r2detail*.000095-pit*.00013-scrape*.000035;
   // A=06 bypasses the new layer exactly, without rebuilding or moving camera.
   vec4 finishDetail=vec4(0.);
   float finishGain=uFinish*uBio.w;
   if(finishGain>0.00001)finishDetail=r2Finish(p,seed,fp)*finishGain;
   structuralHeight+=finishDetail.x;
   structuralHeight-=crack*.00038;
   structuralHeight+=(1.-skin)*(grain-.5)*.00018*band(fp,390.);
   structuralHeight-=shellEdge*.000045*(.35+.65*damage);
   height=structuralHeight*uSurface.x;

   // Curvature/structure proxy is material-space and comes from the generated relief,
   // edge state and damage masks. It is not an independent colour-noise layer.
   float reliefN=clamp(.5+structuralHeight/.00062,0.,1.);
   float raised=smoothstep(.56,.82,reliefN);
   float recessed=1.-smoothstep(.19,.46,reliefN);
   float curvatureProxy=clamp(.30*raised+.32*recessed+.30*shellEdge+.26*pit+.34*crack+.14*scrape,0.,1.);

   // Colour comes after structure. Firing/mineral identity is preserved, then weathered
   // colour zones are derived from recesses, edges, pits and cracks.
   float individual=clamp(.50+(tint-.5)*uColor.z,0.,1.);
   float kilnDelta=(tint-.5)*uColor.z;
   vec3 body=mix(vec3(.050,.064,.071),vec3(.142,.151,.149),individual);
   float mineralWarm=smoothstep(.73,.90,fired*.76+macro*.16+colony*.08)*uSurface.y;
   float recessWash=weather*smoothstep(.31,.87,.50*recessed+.20*curvatureProxy+.14*middle+.08*macro+.08*colony);
   float edgePale=weather*smoothstep(.31,.83,.58*shellEdge+.23*raised+.14*scrape+.05*(1.-colony));
   body=mix(body,vec3(.238,.229,.204),recessWash*.58);
   body=mix(body,vec3(.181,.108,.050),mineralWarm*.24);
   body=mix(body,vec3(.174,.181,.174),edgePale*.18);
   body*=1.+.18*kilnDelta;
   body+=vec3(-.008,-.002,.009)*kilnDelta;
   float coolBroad=ceramicWave(q,seed+73.+tileId*19.,5.2);
   float coolMid=ceramicWave(q,seed+101.+colony*13.,18.0);
   float cool=smoothstep(.58,.80,coolBroad*.68+coolMid*.22+colony*.10);
   body=mix(body,vec3(.036,.050,.060),cool*.19);
   body*=1.-.075*recessed*weather;
   body*=1.-pit*.13-crack*.08;
   body*=1.-finishDetail.z*.14;
   body+=vec3(.012,.013,.012)*scrape;
   body*=vec3(1.+.13*uColor.y,1.+.015*uColor.y,1.-.14*uColor.y)*uColor.x;
   base=mix(body,vec3(.026,.027,.022),crack*.82);

   // Exposed clay remains a specific reference-guided recipe.
   vec3 core=mix(vec3(.245,.182,.102),vec3(.38,.245,.102),uColor.w)*(.83+.30*grain+.08*middle);
   base=mix(core,base,skin);

   // Roughness is a separate field. Structure can modify it, but colour does not drive it.
   float roughField=.5;
   if(fp*247.<.95)roughField=mix(.5,n3(q*247.3+vec3(6.4,2.2,9.7)),band(fp,247.));
   float localWear=n3(q*32.7+vec3(7.1,2.8,5.2)+vec3(tileId*3.7));
   rough=clamp(.835+.105*(roughField-.5)+.070*recessed+.070*pit+.095*crack+.042*shellEdge-.050*scrape-r2detail*.016+.028*(localWear-.5)*mix(.35,1.,colony),.69,.985);
   rough=clamp(rough+finishDetail.w,.69,.985);
   rough*=1.-uSurface.w*.16;base*=1.-uSurface.w*.15;
   ao=1.-crack*.25-pit*.15-recessed*.035;

   if(uBio.x>.001&&vMeta.x>.6&&vState.w>.015){
    float env=clamp(vState.w,0.,1.);
    float bioColony=.50*env+.17*macro+.10*middle+.11*n3(q*3.7+vec3(2.1,7.3,4.4))+.12*colony;
    float edge=.90-.34*uBio.x;
    float cover=smoothstep(edge-.06,edge+.06,bioColony);
    cover*=smoothstep(-.10,.38,N.y);
    vec3 moss=mix(vec3(.026,.035,.010),vec3(.110,.125,.040),clamp(middle*.65+grain*.35,0.,1.));
    base=mix(base,moss,cover*.94);height+=(grain-.5)*.00020*cover*uSurface.x;
    rough=mix(rough,.98,cover);ao*=1.-cover*.08;
   }

 }
 else if(uType==1){
   // Axial wood recipe: nested, nonuniform growth layers and long fibre grooves.
   float fibre=n3(vec3(q.x*480.,q.y*480.,q.z*13.));
   float warp=n3(vec3(q.x*49.,q.y*49.,q.z*9.));
   vec2 center=vec2(.0034*sin(p.z*9.+seed)+.006*exp(-pow((p.z-.068)/.036,2.)),.0021*sin(p.z*6.+seed*.3));
   float radius=length(p.xy-center);
   float rings=radius*5100.+warp*6.5+sin(radius*1210.+seed)*1.6;
   float ringMask=pow(.5+.5*sin(rings),8.)*band(fp,810.);
   float fibres=smoothstep(.48,.78,fibre);
   float streak=n3(vec3(q.x*96.,q.y*96.,q.z*2.8));
   float soft=.5;if(fp*1510.<.95)soft=n3(vec3(q.x*1510.,q.y*1510.,q.z*83.));
   base=mix(vec3(.073,.039,.016),vec3(.196,.146,.078),middle*.58+macro*.22);
   float weather=clamp(uSurface.z*.75+damage*.3,0.,1.);
   base=mix(base,vec3(.134,.125,.099)*(.73+.51*streak),weather*.72);
   base*=1.-.19*ringMask-.23*fibres;
   float longCrack=smoothstep(.72,.91,n3(vec3(q.x*153.,q.y*153.,q.z*3.4)))*band(fp,140.);
   base=mix(base,vec3(.043,.032,.019),longCrack*.6);
   float r2wood=r2mm(vec3(q.x*1.8,q.y*1.8,q.z*.32),seed+17.,fp)*uBio.w;
   height=((fibre-.5)*.00054*band(fp,440.)-ringMask*.00024+(soft-.5)*.000061*band(fp,1400.)+r2wood*.000105-longCrack*.00055)*uSurface.x;
   base*=1.+.025*r2wood;
   if(vMeta.x<.1){base=mix(vec3(.154,.099,.041),vec3(.28,.19,.085),middle)*(.94-ringMask*.27);height+=(middle-.5)*.00043;}
   rough=.95;ao=1.-longCrack*.26;base*=uColor.x;
 }
 else if(uType==2){
   float tufts=n3(q*1791.),fine=n3(q*4073.);
   base=mix(vec3(.018,.030,.006),vec3(.085,.112,.020),clamp(vMeta.x*.58+middle*.18+macro*.11+tufts*.17,0.,1.));
   base=mix(base,vec3(.14,.11,.033),smoothstep(.60,.83,macro)*.46);
   height=((tufts-.5)*.00020*band(fp,1791.)+(fine-.5)*.000043*band(fp,4073.))*uSurface.x;
   rough=.97;ao=.83+.17*tufts;
 }
 else{base=vec3(.68,.685,.663);rough=.94;}
 if(uType!=3 && uDiagnostic!=1)N=perturb(N,vWorld,height);
 if(uDiagnostic==1){base=vec3(.30);rough=.88;}
 if(uDiagnostic==2){fragColor=vec4(N*.5+.5,1);return;}
 vec3 L=normalize(uLight),V=normalize(uEye-vWorld),H=normalize(V+L);
 float NoL=max(dot(N,L),0.),NoV=max(dot(N,V),.05),NoH=max(dot(N,H),0.),VoH=max(dot(V,H),0.);
 vec3 sc=vShadow.xyz/vShadow.w*.5+.5;float shadow=1.;
 if(uShadowEnabled>.5&&sc.x>0.&&sc.x<1.&&sc.y>0.&&sc.y<1.&&sc.z<1.){
   float z=sc.z-max(.000065,.00021*(1.-NoL));shadow=0.;
   for(int y=0;y<2;y++)for(int x=0;x<2;x++)shadow+=texture(uShadow,vec3(sc.xy+(vec2(x,y)-.5)*uShadowTexel*1.8,z))*.25;
 }
 float alpha=rough*rough,a2=alpha*alpha,den=NoH*NoH*(a2-1.)+1.;
 float D=a2/(3.14159265*den*den);
 float k=(rough+1.)*(rough+1.)*.125,G=(NoV/(NoV*(1.-k)+k))*(NoL/(NoL*(1.-k)+k));
 float F=.034+.966*pow(1.-VoH,5.);
 float spec=D*G*F/(4.*NoV*max(NoL,.04));
 vec3 sky=mix(vec3(.31,.29,.26),vec3(.69,.75,.78),N.y*.5+.5);
 float fill=max(0.,dot(N,normalize(vec3(1.2,.6,-.8))));
 vec3 col=base*(sky*.57+vec3(.24,.26,.28)*fill)*ao+base*NoL*1.25*shadow+spec*NoL*vec3(1.15,1.11,1.03)*shadow;
 if(uType==3)col=base*(.77+.23*NoL)*(.72+.28*shadow);
 // A restrained shoulder; linear light is converted once to sRGB.
 col=col/(1.+col*.18);fragColor=vec4(srgb(col),1.);
}
#version 300 es
precision highp float;
precision highp int;
layout(location=0) in vec3 aPosition;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aMeta;
layout(location=3) in mat4 aModel;
layout(location=7) in vec4 aState;
uniform mat4 uVP,uLightVP;
uniform int uType;
out vec3 vWorld,vLocal,vNormal;
out vec4 vShadow;
out vec2 vMeta;
flat out vec4 vState;
float handHash(float x){return fract(sin(x*12.9898+78.233)*43758.5453123);}
vec3 handmadeOffset(vec3 p,vec2 meta,float sid){
 if(meta.y<.5)return vec3(0.);
 float halfW=meta.y>1.5?.0575:.1210;
 float len=meta.y>1.5?.2220:.2380;
 float u=clamp(p.x/halfW,-1.,1.),t=clamp(p.z/len+.5,0.,1.);
 float sideKeep=max(0.,1.-u*u);sideKeep*=sideKeep;
 float endKeep=sin(3.14159265*t);endKeep*=endKeep;
 float a=handHash(sid*1.113)-.5,b=handHash(sid*2.173+3.1)-.5,c=handHash(sid*4.317+1.7)-.5,d=handHash(sid*7.919+5.2)-.5;
 float broad=a*.00280+b*.00140*sin(2.3*u+1.7*t+c*4.0)+c*.00090*(2.*t-1.)+d*.00070*u;
 float dy=sideKeep*endKeep*broad;
 float sideEdge=pow(abs(u),12.),endEdge=pow(abs(2.*t-1.),12.);
 float dx=sideEdge*(a*.00034+b*.00018*sin(t*7.1+d*3.0))*sign(u);
 float dz=endEdge*(c*.00055+d*.00028*sin(u*5.3+a*4.0));
 return vec3(dx,dy,dz);
}
void main(){
 vec3 local=aPosition,localN=aNormal;
 if(uType==0 && aMeta.y>.5){
   vec3 off=handmadeOffset(aPosition,aMeta,aState.x);local+=off;
   if(abs(aNormal.y)>.25){
     float e=.0010;
     float dx=(handmadeOffset(aPosition+vec3(e,0,0),aMeta,aState.x).y-handmadeOffset(aPosition-vec3(e,0,0),aMeta,aState.x).y)/(2.*e);
     float dz=(handmadeOffset(aPosition+vec3(0,0,e),aMeta,aState.x).y-handmadeOffset(aPosition-vec3(0,0,e),aMeta,aState.x).y)/(2.*e);
     float sy=sign(aNormal.y);localN=normalize(aNormal+vec3(-dx*sy,0.,-dz*sy));
   }
 }
 vec4 p=aModel*vec4(local,1.);
 vec3 a=aModel[0].xyz,b=aModel[1].xyz,c=aModel[2].xyz;
 vNormal=normalize(a*localN.x/dot(a,a)+b*localN.y/dot(b,b)+c*localN.z/dot(c,c));
 vLocal=local;
 if(uType==1) vLocal=aPosition*vec3(length(a),length(b),length(c))+vec3(0,0,aState.w);
 vWorld=p.xyz;vShadow=uLightVP*p;vMeta=aMeta;vState=aState;gl_Position=uVP*p;
}
# 云南院落历史建筑生产线 V5.5.0

这是当前稳定的全量本地工程。默认页面直接显示完整的一颗印建筑，使用 WebGL 深度缓冲处理旋转遮挡，并包含门窗自动开合、人物入户、穿过倒座、进入天井、沿小厦到楼梯巷、登上二层大厦的演示。

![当前完整建筑](docs/images/preview.png)

## 快速打开

最稳妥的本地方式是启动静态服务器：

Windows 双击 `START_LOCAL_WINDOWS.bat`。

Windows PowerShell 运行 `./START_LOCAL_WINDOWS.ps1`。

macOS 或 Linux 运行 `./start_local_mac_linux.sh`。

也可以直接打开 `index.html`。部分浏览器对本地文件的权限策略较严格，遇到加载或交互限制时使用本地服务器。

V5.5.0 墙面与瓦顶生产验收页为 `surface-production-lab.html`。它使用仓库内的 Three.js 与 OrbitControls，左右画面共享同一完整建筑结构、种子、相机和光照，不依赖 CDN。左侧只启用 V5.4.4 瓦作与表面路径，右侧启用 V5.5.0 路径；页面可切换三套旧化预设、几何推导的验收镜头、屋面爆炸分层、墙面历史层、门窗开合和人物入户上楼。

## GitHub 上传

直接上传 GitHub 时，优先使用同批交付的 `github-ready.zip`。它已经排除本地参考图片和临时文件。

命令行推送可以运行：

```powershell
./PUSH_TO_GITHUB.ps1 -RepoUrl "你的仓库地址"
```

或：

```bash
./push_to_github.sh "你的仓库地址"
```

仓库推送到 `main` 后，内置 GitHub Pages 工作流会先执行静态验证，再发布 `index.html`；V5.5.0 Draft 验收分支使用独立的 `github-pages-preview` 环境部署同一 commit 并运行公开页面 QA。第一次部署前需要在仓库 Settings 的 Pages 页面把 Source 设为 GitHub Actions。公开生产线中的“GitHub同步”入口按部署 `build.json` 的 SHA/ref 读取四个必需生产数据文件、最新提交和 `[Web Sync]` Issue；网页端命令与现场记录可先留在本地队列，也可由用户主动用 Fine-grained token 提交为 Issue，形成可审计的回传链路。

## 当前稳定能力

1. 一颗印完整院落默认入镜。
2. WebGL 深度测试解决旋转时的错误穿面。
3. 院内观察只改变镜头，剖切单独控制。
4. 双扇大门、正房上层门和四组高窗可以自动开合。
5. 人物可以进入天井并沿楼梯到达二层。
6. 滇中一颗印与滇西纳西民居归入云南院落民居母系统。
7. 平面、间架、剖面、屋面、门窗和交通逻辑保存在独立 JSON 数据中。
8. 页面为单文件自包含版本，不依赖外部 CDN。
9. 新增“云南民居三开间带前廊两层建筑”测绘个案：11.53 m 面阔、7.92 m 进深、1.87 m 前廊、2.85 m 二层与 7.04 m 屋脊。
10. 个案按四副横向梁架生成，两山穿斗式、中间两副抬梁式；主体悬山与前廊披檐保持独立。
11. 单片收分板瓦/筒瓦已在本地 WebGL 的屋顶、檐口、正立面和人眼入口视角完成复查；楼梯沿用已确认的 8+8 级双跑日常木梯。
12. 已将用户确认来自团结乡的完整院落扫描登记为 `YN_TUANJIE_001`（旧别名“民居 C2 美人靠”）：Lite/High GLB、源 FBX/贴图、样本拆分、尺度证据边界和资产契约均可回溯；它作为参考观察层，不替代程序化构件。
13. 已建立团结乡连续样本登记规则，后续建筑按稳定编号追加；当前 GLB 包围盒只作展示尺度，真实尺寸须由测绘控制点校准。
14. “团结乡样本”页提供同一套 48 网格扫描几何的双档 GLB：本地选择的 `YN_TUANJIE_001_EDITABLE_HIGH.glb` 保留 7000×7000 底色和 2500×2500 法线，公开请求的 `YN_TUANJIE_001_EDITABLE.glb` 保留 3072×3072/1024×1024 网页标准贴图；两档均按场地、未定细部、一层、二层和屋顶建立可编辑父分组。
15. 修复直接双击 `index.html` 时浏览器阻止 `file://` 读取 GLB 而显示空白的问题：查看器始终可见，本地模式可选择或拖入下载后的 GLB；通过启动脚本访问时仍可一键读取内置主档。
16. 团结乡查看器现读取并应用内嵌法线贴图，启用各向异性纹理过滤和最高 2.5 倍设备像素比；界面明确显示当前实际载入档位、贴图分辨率和扫描源固有破边边界。
17. “团结乡样本”页新增“云南大理参考”和“浩思一·乌龙 WL”两个公开 GLB 按钮；网页端直接加载 `assets/models/YN_DALI_001_REFERENCE_WEB.glb` 与 `assets/models/YN_HAOSI1_WULONG_WL_001_REFERENCE_WEB.glb`，本地模式可分别选取 `yunnan_dali_1.glb` 与 `yunnan_house1_wl.glb` 原档。
18. 大理与乌龙公开档只降采样嵌入贴图以满足 GitHub Pages 体量限制，顶点、索引、网格数量和三角面保持不变；源文件哈希、几何审计和网页加载验收见 `data/evidence/` 与 `data/qa/`。
19. V5.5.0 程序化一颗印生成七个有真实几何的独立屋面单元，屋面包含檩条、椽列、基层、板瓦、筒瓦、檐端与脊部七层。板瓦与筒瓦使用独立闭合曲面和实例批次，筒瓦列数按相邻板瓦缝推导，滴水与勾头分别对应板瓦列与筒瓦列。
20. 瓦顶使用稳定低频场生成日晒、灰尘、雨蚀、苔藓、磨损、缺瓦、破损与连续修补片区；墙面具有土体、抹灰、裸土、草纤维、石勒脚、砖包角、返潮、雨痕、剥落、裂缝、污渍和修补实体层。
21. 活动门窗采用真实铰轴父组；人物路线穿过南门并使用一座 8+8 双跑楼梯，楼梯含下跑、中间平台、反向上跑、上下落脚平台与连续扶手。Surface QA 请求至少 36 个渲染完成帧并硬性要求至少 30 帧、25 个唯一世界位置；本轮一次隔离本地验收取得 57 帧/57 个唯一位置。路线另以 300 个真实落脚/支撑样本及 335 个加密胶囊扫掠点保持最大 0.079874 m 的碰撞采样间距。
22. 根目录 Actions 工作流运行静态验证、V5.5.0 Playwright 冒烟和完整生产线浏览器回归，并输出覆盖 11 类检查的 16 张 Surface 截图：完整建筑、同结构同镜头 A/B、檐口、七层爆炸、脊部和靠墙收口、墙瓦风化、门窗、人物路线、8+8 楼梯及移动端。团结乡、大理、乌龙村分别真实加载、渲染并保存独立画面。
23. 檩条、椽列、板瓦、筒瓦和脊部收边使用共享 Geometry 与逐坡实例批次；墙体结构与八类表面语义合并为 9 个保留 RGB 顶点色和独立 alpha 的静态索引批次，裂缝使用单一 InstancedMesh，草纤维使用单一静态顶点批次。渲染 Mesh 的静态局部矩阵被冻结，门窗铰轴、人物和爆炸层父组保持活动。当前完整场景审计为 574612 个 renderer 三角面、574820 个场景三角面、13061 个实例、407 个 draw calls 和 407 个 mesh；本轮一次单次无重试 SwiftShader 样本为桌面 7.48 FPS、390×844 移动端 8.23 FPS，工作流门槛均为 5 FPS。
24. 同结构 A/B 的左侧实际执行冻结的 `threejs/v544/YunnanMaterialFactory.js`，右侧执行当前 V5.5.0 材质与风化工厂；QA 从真实编译后的 shader 读取两侧运行时证据。七屋面坡数严格固定为 `2+2+2+2+1+3+2=14`，16 张截图逐张解码并要求非空像素与颜色变化。

## 工程目录

```text
index.html                         当前稳定网页
404.html                           GitHub Pages 回退页
.github/workflows/                 自动验证与 Pages 部署
data/                              当前系统、类型、构件、交互和验收数据
docs/                              架构、工作法、部署、验收和后续路线
qa/screenshots/                    当前版本和建筑逻辑检查图
tools/                             本地启动、验证、浏览器冒烟测试和打包工具
references-private/                用户提供的研究资料，本地保留，Git 默认忽略
threejs/                           Three.js 3GIS 参考资产加载入口与清单
AGENTS.md                          Codex 与后续开发窗口的强制规则
PROJECT_STATE.md                   当前项目状态与下一步
```

## 提交前强制验证

```bash
python tools/validate.py
node --check assets/js/surface-production-lab.js
node --check threejs/YunnanCourtyardProduction.js
node --check threejs/YunnanMaterialFactory.js
node --check threejs/YunnanRoofSurfaceSystem.js
node --check threejs/YunnanWallSurfaceSystem.js
python tools/surface_production_smoke.py
python tools/browser_smoke_test.py
python tools/make_release.py
git diff --check origin/main...HEAD
```

浏览器命令需要先安装 `requirements-dev.txt` 和 Playwright Chromium。任一命令、Surface QA、完整生产线回归、Pages 部署或公开验证失败/跳过时，工作流保持失败。

## 当前资料边界

板瓦与筒瓦已依据用户提供的本地草测图建立为有大小口收分的单片曲面实体：板瓦凹面朝上居下，筒瓦凸面朝上逐片压缝。坡向露明量按用户实景照片作视觉校准，不冒充实测搭接尺寸；精确纵向搭接、泥背厚度、檐口固定与屋脊端部仍待节点图锁定。传统窗扇的地方五金与精确开启方式仍待近照和节点图校准。纳西支系已经具有平面类型与楼型语法，完整米制测绘模型仍待资料补齐。三开间前廊个案的地点、年代和族属尚未由资料确定。

## 参考图片与版权

`references-private/` 保存本地研究资料，默认写入 `.gitignore`。公开仓库上传前请核实图片版权、引用条件和署名。网页运行不依赖这些图片。

`references-private/c2-meirenkao/` 保存团结乡样本 01 的源 FBX、贴图和 GLB，目录名作为旧资产兼容路径保留。当前生产线页面仍保持无外部依赖的程序化 WebGL 展示；Three.js 3GIS 宿主可按 `threejs/C2MeirenkaoAsset.js` 加载该参考层。团结乡系列登记册见 `docs/TUANJIE_TOWNSHIP_REFERENCE_REGISTER.md`。

## 许可

本包没有预设开源许可证。公开发布、协作或商业使用前，请由项目所有者选择并加入合适的许可证。

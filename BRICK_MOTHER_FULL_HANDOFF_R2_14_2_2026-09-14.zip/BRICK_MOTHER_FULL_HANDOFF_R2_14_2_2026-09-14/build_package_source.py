from pathlib import Path
import subprocess, json, re, hashlib, zipfile, shutil
ROOT=Path('G:/HOUSE')
OUT=ROOT/'brick-mother-package-20260914'
NAME='BRICK_MOTHER_FULL_HANDOFF_R2_14_2_2026-09-14'
PKG=OUT/NAME
PKG.mkdir(exist_ok=True)
REV='61e59bd01824d11e20a5de67b154dafe63278bdc'
PREFIX='yunnan-courtyard-architecture-factory-v5.2.1-full-local/yunnan-courtyard-architecture-factory-v5.2.1-full-local/brick-mother/'
def git(*args): return subprocess.check_output(['git','-C',str(ROOT),*args])
def put(path,data):
    p=PKG/path; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(data)
def jsave(path,data): put(path,(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode())
paths=git('ls-tree','-r','--name-only',REV).decode().splitlines()
skill_dirs=[p.rsplit('/',1)[0]+'/' for p in paths if p.startswith(PREFIX) and p.endswith('SKILL.md')]
excluded=[]; count=0
for p in paths:
    if not (p.startswith(PREFIX) or p.startswith('.github/workflows/brick')): continue
    if any(p.startswith(d) for d in skill_dirs) or p.lower().endswith(('.zip','.7z','.tar','.gz')):
        excluded.append({'path':p,'reason':'Legacy skill directory or opaque historical archive; excluded to prevent reintroducing revoked workflows.'}); continue
    local='repository/brick-mother/'+p[len(PREFIX):] if p.startswith(PREFIX) else 'repository/'+p
    put(local,git('cat-file','blob',REV+':'+p)); count+=1
for folder in ['brick-mother-continuation-20260912','brick-mother-sync-20260914']:
    for p in (ROOT/folder).rglob('*'):
        if folder=='brick-mother-sync-20260914' and 'source' in p.relative_to(ROOT/folder).parts: continue
        if p.is_file() and p.suffix.lower() not in ('.zip','.pyc') and '__pycache__' not in p.parts:
            put('local-history/'+folder+'/'+p.relative_to(ROOT/folder).as_posix(),p.read_bytes())
prior=ROOT/'brick-mother-intake-a354d0d4/BRICK_MOTHER_CURRENT_FULL_HANDOFF_R1_2026-09-12'
for p in prior.glob('*'):
    if p.is_file() and p.suffix in ('.md','.json'): put('prior-handoff-metadata/'+p.name,p.read_bytes())
for name in ['MOTHER_OBJECT_DEFINITION_RULE_2026-09-09.md','MOTHER_PUBLIC_PREVIEW_DELIVERY_RULE_2026-09-08.md']:
    put('rules/'+name,(Path('G:/小妈')/name).read_bytes())
put('rules/HOUSE_AGENTS_AT_SYNC.md',(ROOT/'AGENTS.md').read_bytes())
# Resolve immutable GitHub HTML dependencies directly from git blobs, preserving original bytes.
url_re=re.compile(r'https://(?:rawcdn\.githack\.com|raw\.githack\.com|raw\.githubusercontent\.com)/haihao0307/HOUSE/([0-9a-f]{40})/([^\s\x22\x27<>`\\)]+)')
entry='https://rawcdn.githack.com/haihao0307/HOUSE/d40492520f2638437a3eb729d442ff778e26bc9c/'+PREFIX+'experiments/shape-edge-lab-r2-14/Brick_Shape_Edge_Lab_R2_14.html'
queue=[entry]; deps={}; issues=[]
while queue:
    url=queue.pop(0)
    if url in deps: continue
    m=url_re.fullmatch(url)
    if not m: raise RuntimeError(url)
    rev,path=m.groups(); path=path.split('?')[0]
    if 'SKILL.md' in path or any(path.startswith(d) for d in skill_dirs): raise RuntimeError('Forbidden dependency '+path)
    data=git('cat-file','blob',rev+':'+path)
    local='runtime-dependencies/'+rev+'/'+path.rsplit('/',1)[-1]
    deps[url]=local; put(local,data)
    if path.endswith(('.html','.js','.css','.json')):
        source=data.decode('utf-8')
        queue.extend(m.group(0) for m in url_re.finditer(source) if m.group(0) not in deps)
        other=re.findall(r'https?://[^\s\x22\x27<>`\\)]+',source)
        for u in other:
            if not url_re.fullmatch(u): issues.append({'file':local,'url':u})
jsave('DEPENDENCY_LOCK.json',{'entry':entry,'url_to_file':deps,'other_urls_to_review':issues})
jsave('EXCLUSIONS.json',excluded)
jsave('SOURCE_LOCK.json',{'repository':'https://github.com/haihao0307/HOUSE','branch':'codex/brick-r25-glb-shape-final','commit':REV,'candidate':'R2.14.2','geometry_commit':'d40492520f2638437a3eb729d442ff778e26bc9c','snapshot_files':count,'original_reference_glb':'Not found in fetched Brick source or current local handoff. Derived EDGE_FIELD_COEFFICIENTS.json and observation notes included. Original GLB is not claimed included.'})
print(json.dumps({'source_files':count,'dependency_files':len(deps),'other_urls':issues,'excluded_count':len(excluded)},ensure_ascii=False))


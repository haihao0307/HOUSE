from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent
m=json.loads((p/'MANIFEST_SHA256.json').read_text(encoding='utf-8'))
actual={f.relative_to(p).as_posix() for f in p.rglob('*') if f.is_file() and f.name!='MANIFEST_SHA256.json' and '__pycache__' not in f.parts}
assert actual==set(m), 'File inventory differs'
for name,rec in m.items():
    data=(p/name).read_bytes()
    assert len(data)==rec['bytes'] and hashlib.sha256(data).hexdigest()==rec['sha256'],name
print('PASS:',len(m),'files verified')

# User acceptance and freezes

## Freeze / preserve
- Irregular rubble stone: user said it passed 100%; do not alter its accepted default DNA.
- Adobe: user said it is basically correct; preserve current default DNA and isolate any later detail edits.
- Fired brick B direction: Process-driven shared masks plus fragment-level Macroscopic microscope is the accepted direction.

## Reject from the production path
- Old independent-noise / fake-roughness material path. It can remain only as historical comparison evidence inside this frozen handoff; it must not drive future production.

## Not yet approved
- Final fired-brick material strength and shape.
- Layered stone, dressed masonry stone and pebble final appearance.
- Any production-ready claim.

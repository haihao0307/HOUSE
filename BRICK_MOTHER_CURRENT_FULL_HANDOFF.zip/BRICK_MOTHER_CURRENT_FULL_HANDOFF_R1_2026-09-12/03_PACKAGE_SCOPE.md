# Package scope

Included:
- the complete current Brick Mother text/source/knowledge/experiment tree at the source snapshot;
- all Brick-related GitHub workflow files and kick records present at the snapshot;
- latest successful Material Microscope Lab real-browser QA evidence;
- current user acceptance/freeze decisions and next-step contract;
- SHA256 manifest and verifier.

Excluded intentionally:
- nested historical ZIP/TAR archives, to avoid recursive archive bloat;
- unrelated HOUSE / Tiles / architecture source trees;
- approval claims not explicitly granted by the user.

import hashlib, json, pathlib, sys
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST_SHA256.json').read_text(encoding='utf-8'))
bad=[]
for rel, meta in manifest.items():
    p=root/rel
    if not p.is_file():
        bad.append((rel,'missing')); continue
    b=p.read_bytes(); h=hashlib.sha256(b).hexdigest()
    if h!=meta['sha256'] or len(b)!=meta['bytes']:
        bad.append((rel,'mismatch'))
if bad:
    print(json.dumps({'ok':False,'bad':bad},ensure_ascii=False,indent=2)); sys.exit(1)
print(json.dumps({'ok':True,'files':len(manifest)},ensure_ascii=False))

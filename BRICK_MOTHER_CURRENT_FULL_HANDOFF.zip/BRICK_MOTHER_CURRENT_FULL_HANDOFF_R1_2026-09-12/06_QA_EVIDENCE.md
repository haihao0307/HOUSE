# QA evidence

Material Microscope Lab R1 first browser attempt failed on a WebGL/ESSL structure ternary and was not accepted as evidence.
The shader was corrected and the next real-browser run succeeded:
- run: 34662919726
- artifact: 10288406212
- fixed HTML commit: 201fb2c22eaa31d3783bbf35d4294c33eb1bcc81
- evidence copied into qa/material-microscope-lab-r1/

The QA evidence covers local Chromium/WebGL2 modes and fixed public mobile opening. It proves the experiment runs; it does not by itself prove visual approval.

# Pending and next

Next implementation round is deliberately narrow:

1. Fired brick only.
2. Keep Process + fragment-level Macroscopic microscope as the sole forward path.
3. Add user-facing sliders for:
   - Microscope Strength
   - Microscope Scale
   - Microscope Height Contribution
   - Microscope Roughness Contribution
4. Increase the useful microscope contribution without reintroducing unrelated random noise.
5. Preserve fixed camera/light A/B diagnostics: Beauty, Height, Roughness, Material Masks, Microscope OFF/ON.
6. Only after the material controls read correctly, continue brick body shape/edge/chip refinement.

Do not broaden the round into all seven families.

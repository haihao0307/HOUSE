# Xiaoma review / root-cause checkpoint

Before the Material Microscope Lab, the production path had two structural mistakes:
1. the Macroscopic microscope field was baked per vertex and linearly interpolated, suppressing high-frequency gradient detail;
2. formal stone/pebble presets with uRock>0 bypassed that microscope scalar altogether.

The isolated lab therefore evaluates the 17-layer microscope per fragment with screen-footprint octave gating and uses shared process masks for fired-brick BaseColor / Roughness / Height. Yohei-style scale organization is a detail organizer, not a substitute for material identity.

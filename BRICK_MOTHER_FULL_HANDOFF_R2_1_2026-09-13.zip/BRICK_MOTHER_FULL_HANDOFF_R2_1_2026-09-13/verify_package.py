from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST_SHA256.json').read_text(encoding='utf-8'))
bad=[]
for rel,info in m.items():
 p=r/rel
 if not p.is_file():bad.append([rel,'missing']);continue
 b=p.read_bytes()
 if len(b)!=info['bytes'] or hashlib.sha256(b).hexdigest()!=info['sha256']:bad.append([rel,'mismatch'])
print(json.dumps({'ok':not bad,'files':len(m),'bad':bad},ensure_ascii=False))
raise SystemExit(bool(bad))

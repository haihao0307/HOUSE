from pathlib import Path
import re

root=Path(__file__).resolve().parent
source=root.parent/'brick-mother-intake-a354d0d4/BRICK_MOTHER_CURRENT_FULL_HANDOFF_R1_2026-09-12/repository/brick-mother/experiments/material-microscope-lab-r1/Brick_Material_Microscope_Lab_R1.html'
old=source.read_text(encoding='utf-8')
vs=re.search(r'const vs=`(.*?)`;',old,re.S).group(1)
fs=re.search(r'const fs=`(.*?)`;',old,re.S).group(1)
fs=fs.replace('uniform vec2 uRes;', 'uniform vec2 uRes;uniform vec2 uOrigin;uniform vec4 uMicro;')
fs=fs.replace('vec3 c=vec3(id<.5?-1.32:1.32,0.,0.);return rotInv(p-c);','return rotInv(p);')
fs=re.sub(r'vec2 map\(vec3 p\)\{.*?return o;\}', 'vec2 map(vec3 p){vec2 o=vec2(sdRoundBox(rotInv(p),vec3(1.04,.43,.50),.075),1.);float floorD=p.y+.72;if(floorD<o.x)o=vec2(floorD,2.);return o;}',fs)
fs=re.sub(r'Mat oldMaterial\(vec3 q\)\{.*?return m;\}\n','',fs)
fs=fs.replace('float mm=microscope(q*9.5);', 'float mm=microscope(q*9.5*uMicro.y);float contribution=uMM*uMicro.x;float grain=clamp(mm,-1.,1.)*(.65+.35*skin);m.rough=clamp(m.rough+contribution*uMicro.w*grain*.12,.45,.985);')
fs=fs.replace('float micro=uMM*mm*.0034;', 'float micro=contribution*uMicro.z*mm*.0034;')
fs=fs.replace('Mat m;if(id<.5)m=oldMaterial(q);else m=processMaterial(q);', 'Mat m=processMaterial(q);')
fs=fs.replace('return id<.5?vec3(m.mask.xyz):vec3(m.mask.x,m.mask.y,m.mask.z);', 'return vec3(m.mask.x,m.mask.y,m.mask.z);')
fs=fs.replace('(gl_FragCoord.xy-.5*uRes)', '(gl_FragCoord.xy-uOrigin-.5*uRes)')
# Diagnostic scalar values remain linear instead of receiving beauty tone mapping.
fs=fs.replace('float vign=1.-.24*dot(uv,uv);', 'if(ok&&hit.y<1.5&&uMode>0){frag=vec4(col,1.);return;}float vign=1.-.24*dot(uv,uv);')
html='''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Brick Mother · 显微材质 R2</title><link rel="icon" href="data:,">
<style>
:root{color-scheme:dark;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;background:#101410;color:#e9e5da}*{box-sizing:border-box}body{margin:0}button,input{font:inherit}button{cursor:pointer;background:#232a23;border:1px solid #485045;border-radius:7px;padding:8px 12px;color:#dfded4;font-size:12px}button:hover{background:#343b30}button:focus-visible,input:focus-visible{outline:2px solid #efc28b;outline-offset:3px}button.active{border-color:#d4aa6a;background:#3b3023;color:#ffe6c1}main{display:flex;flex-direction:column;min-height:100svh;height:100svh}header{padding:16px 24px 12px;border-bottom:1px solid #ffffff14;display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap}h1{font-size:16px;letter-spacing:.08em;margin:0 0 5px}.sub{font-size:11px;color:#a4ad9f}.modes{display:flex;gap:6px;flex-wrap:wrap}.stage{position:relative;flex:1;min-height:300px;overflow:hidden;background:#151b16}canvas{display:block;width:100%;height:100%;touch-action:none}.labels{position:absolute;inset:0;display:grid;grid-template-columns:1fr 1fr;pointer-events:none}.label{padding:15px 20px;font-size:12px;color:#e4dfd1}.label+ .label{border-left:1px solid #ffffff1c}.label small{display:block;margin-top:5px;font-size:10px;color:#9ba596}.label b{font-weight:500;color:#e5bf89}.hint{position:absolute;bottom:8px;width:100%;text-align:center;color:#8f9b8e;font-size:10px;pointer-events:none}.panel{padding:14px 24px 16px;background:#171d17;border-top:1px solid #ffffff18}.paneltop{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:12px}.paneltitle{font-size:12px;color:#c9cdbf}.actions{display:flex;gap:6px;flex-wrap:wrap}.sliders{display:grid;grid-template-columns:repeat(4,1fr);gap:22px}.control label{display:flex;justify-content:space-between;font-size:12px;gap:8px}.control output{color:#eec891;font-variant-numeric:tabular-nums}.control small{display:block;font-size:10px;color:#97a18f;margin-top:4px}.control input{display:block;width:100%;margin:13px 0 7px;accent-color:#dcb681;cursor:pointer}.footer{font-size:10px;color:#98a190;display:flex;justify-content:space-between;gap:10px;margin-top:13px}.error{position:absolute;inset:0;display:grid;place-content:center;padding:30px;background:#192019;color:#f0c7ac;z-index:3}.error[hidden]{display:none}
@media(max-width:700px){header{padding:12px;gap:10px}h1{font-size:13px}.sub{font-size:10px}.modes{gap:4px}button{padding:7px 9px;font-size:11px}.stage{min-height:320px}.labels{grid-template-columns:1fr;grid-template-rows:1fr 1fr}.label{padding:9px 12px;font-size:11px}.label small{margin-top:2px}.label+.label{border-left:0;border-top:1px solid #ffffff1c}.panel{padding:12px}.sliders{grid-template-columns:1fr 1fr;gap:12px 20px}.control label{font-size:11px}.control input{margin:9px 0 5px}.paneltop{margin-bottom:12px}.footer{font-size:9px;margin-top:10px}.hint{font-size:9px}.actions{gap:4px}}
</style></head><body><main>
<header><div><h1>BRICK MOTHER · 显微材质 R2</h1><div class="sub">烧结砖 / Process · 共享形成遮罩 · 片元级显微结构</div></div><nav class="modes" aria-label="材质诊断"><button data-mode="0" class="active" aria-pressed="true">成品</button><button data-mode="1" aria-pressed="false">高度</button><button data-mode="2" aria-pressed="false">粗糙度</button><button data-mode="3" aria-pressed="false">形成遮罩</button></nav></header>
<section class="stage" aria-label="同几何、同相机、同灯光材质对比"><canvas id="c" aria-label="烧结砖对比，可拖动旋转，滚轮缩放"></canvas><div class="labels"><div class="label">B 基准 <small>R1 参数 · 显微开启 · 固定参照</small></div><div class="label"><b>B 调参</b><small id="tunedLabel">增强预设 · 显微开启</small></div></div><div class="hint">拖动同步旋转 · 滚轮缩放 · 上/左为基准，下/右为调参</div><div id="error" class="error" role="alert" hidden></div></section>
<section class="panel" aria-label="调参侧显微控制"><div class="paneltop"><span class="paneltitle">调参侧 · 显微贡献</span><div class="actions"><button id="mm" class="active" aria-pressed="true">显微：开</button><button id="enhance">增强预设</button><button id="reset">恢复 R1</button><button id="camera">复位视角</button></div></div>
<div class="sliders">
<div class="control"><label for="strength">显微强度 <output id="strengthValue" for="strength">2.00×</output></label><input id="strength" type="range" min="0" max="4" step="0.05" value="2"><small>同时作用于高度与粗糙度</small></div>
<div class="control"><label for="scale">显微尺度 <output id="scaleValue" for="scale">1.00×</output></label><input id="scale" type="range" min="0.25" max="4" step="0.05" value="1"><small>数值越大，显微纹理越密</small></div>
<div class="control"><label for="height">高度贡献 <output id="heightValue" for="height">1.50×</output></label><input id="height" type="range" min="0" max="4" step="0.05" value="1.5"><small>表面凹凸响应，不改变砖体轮廓</small></div>
<div class="control"><label for="roughness">粗糙度贡献 <output id="roughnessValue" for="roughness">1.00×</output></label><input id="roughness" type="range" min="0" max="2" step="0.05" value="1"><small>沿同一显微结构改变表面反光</small></div>
</div><div class="footer"><span id="status" role="status">正在初始化 WebGL2…</span><span>材质实验 · 待视觉验收 · 尺度为模型倍率</span></div></section>
</main><script>
'use strict';
const canvas=document.getElementById('c'),stage=document.querySelector('.stage');
function fail(message){document.getElementById('error').hidden=false;document.getElementById('error').textContent=message;document.getElementById('status').textContent='渲染不可用';}
const gl=canvas.getContext('webgl2',{antialias:true,alpha:false,powerPreference:'high-performance'});
if(!gl){fail('当前浏览器未提供 WebGL2，请使用支持 WebGL2 的浏览器打开。');}else{try{
'''+f'const vs=`{vs}`;\nconst fs=`{fs}`;\n'+'''
function compile(type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));return s;}
const prog=gl.createProgram();gl.attachShader(prog,compile(gl.VERTEX_SHADER,vs));gl.attachShader(prog,compile(gl.FRAGMENT_SHADER,fs));gl.linkProgram(prog);if(!gl.getProgramParameter(prog,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(prog));gl.bindVertexArray(gl.createVertexArray());gl.useProgram(prog);
const U={};for(const n of ['uRes','uOrigin','uMicro','uTime','uYaw','uPitch','uZoom','uMode','uMM'])U[n]=gl.getUniformLocation(prog,n);
const ids=['strength','scale','height','roughness'],reference=[1,1,1,0],enhanced=[2,1,1.5,1];
let values=[...enhanced],yaw=-.22,pitch=.08,zoom=4.8,mode=0,mm=1,drag=false,last=[0,0],pending=false,lost=false;
function refresh(label='自定义'){ids.forEach((id,i)=>{document.getElementById(id).value=values[i];document.getElementById(id+'Value').value=values[i].toFixed(2)+'×';});document.getElementById('mm').textContent=mm?'显微：开':'显微：关';document.getElementById('mm').classList.toggle('active',!!mm);document.getElementById('mm').setAttribute('aria-pressed',String(!!mm));document.getElementById('tunedLabel').textContent=label+' · 显微'+(mm?'开启':'关闭');schedule();}
function draw(){pending=false;if(lost)return;const box=stage.getBoundingClientRect(),d=Math.min(devicePixelRatio||1,1.45),stack=innerWidth<=700;let w=Math.max(2,Math.round(box.width*d)),h=Math.max(2,Math.round(box.height*d));if(stack)h-=h%2;else w-=w%2;if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}const pw=stack?w:w/2,ph=stack?h/2:h;gl.useProgram(prog);gl.uniform1f(U.uTime,0);gl.uniform1f(U.uYaw,yaw);gl.uniform1f(U.uPitch,pitch);gl.uniform1f(U.uZoom,Math.max(zoom,4.1/Math.max(pw/ph,.3)));gl.uniform1i(U.uMode,mode);gl.uniform2f(U.uRes,pw,ph);for(let panel=0;panel<2;panel++){const x=stack?0:panel*pw,y=stack?(1-panel)*ph:0;gl.viewport(x,y,pw,ph);gl.uniform2f(U.uOrigin,x,y);gl.uniform4fv(U.uMicro,panel?values:reference);gl.uniform1f(U.uMM,panel?mm:1);gl.drawArrays(gl.TRIANGLES,0,3);}document.getElementById('status').textContent='WebGL2 · R2 · '+['成品','高度','粗糙度','形成遮罩'][mode];canvas.dataset.ready='true';}
function schedule(){if(!pending&&!lost){pending=true;requestAnimationFrame(draw);}}
ids.forEach((id,i)=>document.getElementById(id).addEventListener('input',e=>{values[i]=Number(e.target.value);refresh();}));
document.getElementById('mm').onclick=()=>{mm=mm?0:1;refresh();};document.getElementById('enhance').onclick=()=>{values=[...enhanced];mm=1;refresh('增强预设');};document.getElementById('reset').onclick=()=>{values=[...reference];mm=1;refresh('R1 参数');};document.getElementById('camera').onclick=()=>{yaw=-.22;pitch=.08;zoom=4.8;schedule();};
document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>{mode=Number(b.dataset.mode);document.querySelectorAll('[data-mode]').forEach(x=>{x.classList.toggle('active',x===b);x.setAttribute('aria-pressed',String(x===b));});schedule();});
canvas.addEventListener('pointerdown',e=>{drag=true;last=[e.clientX,e.clientY];canvas.setPointerCapture(e.pointerId);});canvas.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-last[0],dy=e.clientY-last[1];last=[e.clientX,e.clientY];yaw-=dx*.006;pitch=Math.max(-1.05,Math.min(1.05,pitch+dy*.006));schedule();});for(const ev of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(ev,()=>drag=false);canvas.addEventListener('wheel',e=>{e.preventDefault();zoom=Math.max(3.4,Math.min(7.2,zoom*Math.exp(e.deltaY*.001)));schedule();},{passive:false});
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();lost=true;fail('图形上下文已中断，请刷新页面恢复预览。');});new ResizeObserver(schedule).observe(stage);window.addEventListener('resize',schedule);refresh('增强预设');
}catch(error){console.error(error);fail('材质着色器初始化失败：'+error.message);}}
</script></body></html>
'''
out=root/'material-microscope-lab-r2'
out.mkdir(exist_ok=True)
(out/'Brick_Material_Microscope_Lab_R2.html').write_text(html,encoding='utf-8')
print(out/'Brick_Material_Microscope_Lab_R2.html')

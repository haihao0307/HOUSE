from pathlib import Path
import re
root=Path(__file__).resolve().parent
source=root/'material-microscope-lab-r2/Brick_Material_Microscope_Lab_R2.html'
s=source.read_text(encoding='utf-8')
old='float rr=max(length(q),1e-4);vec3 xi=vec3(log2(rr)-2.,-q.z/rr-1.,atan(q.x,q.y));'
new='''// Smooth the angular pole in object space, on both faces and at every slider scale.
// cos(2^j * acos(y/r)) equals the old cos(2^j * atan(x,y)) away from the pole.
// A localized, positive denominator removes the undefined angle without adding noise.
float rr=max(length(q),1e-4);
float cap=.13*9.5*uMicro.y;
float radial2=dot(q.xy,q.xy);
float angularRadius=sqrt(radial2+cap*cap*exp(-radial2/(cap*cap)));
float angle=acos(clamp(q.y/angularRadius,-.999999,.999999));
vec3 xi=vec3(log2(rr)-2.,-q.z/rr-1.,angle);'''
assert old in s
s=s.replace(old,new).replace('显微材质 R2','显微材质 R2.1').replace('WebGL2 · R2 ·','WebGL2 · R2.1 ·')
s=s.replace('R1 参数 · 显微开启 · 固定参照','基准参数 · 中心修复 · 显微开启').replace('恢复 R1','恢复基准').replace("refresh('R1 参数')","refresh('基准参数')")
out=root/'material-microscope-lab-r2-1';out.mkdir(exist_ok=True)
(out/'Brick_Material_Microscope_Lab_R2_1.html').write_text(s,encoding='utf-8')
print(out)

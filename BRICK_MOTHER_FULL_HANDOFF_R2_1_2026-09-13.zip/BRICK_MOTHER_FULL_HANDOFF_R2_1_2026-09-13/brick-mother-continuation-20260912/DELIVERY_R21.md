# Brick Mother R2.1 修复交付

2026-09-12。用户明确要求先修复中央伪影，之后提供具体边缘参考。本轮仅完成此修复。

[R2.1 固定公网预览](https://rawcdn.githack.com/haihao0307/HOUSE/030d84b979a8158d03398aa60da69e8e3315cd40/yunnan-courtyard-architecture-factory-v5.2.1-full-local/yunnan-courtyard-architecture-factory-v5.2.1-full-local/brick-mother/experiments/material-microscope-lab-r2-1/Brick_Material_Microscope_Lab_R2_1.html)

提交 030d84b979a8158d03398aa60da69e8e3315cd40，分支 codex/brick-microscope-r21-pole-fix。
HTML SHA256 f6756ca476632b0520a967ab9e5295209ca5706a065289cbf03ab63bdd890a65。

通过局部平滑角度半径修复正反面中心的显微极点，保留原17层场、形成遮罩与材料参数。processMaterial 与几何 map 经源码比较完全不变。固定 R2 未改写。

本地及该公网地址均经真实 Chrome/WebGL2 检查，29项通过，无页面/控制台错误。公网正反面近景已查看，中央放射尖点消失，未观察到替代圆环或接缝。四滑杆、四诊断模式、OFF/ON、视角控制、窄屏布局均实际检查。证据位于 qa-r21/public-report.json、pole-front.png、pole-rear.png 及其他截图。

补充数值检查8项通过：材质/几何原文一致性两项、正反面在0.25/1/4尺度下的极点连续性六项。原来中心极小采样环上仍有约0.61–1.83的方向差；修复后降至约6.8e-8–1.4e-6。该检查针对连续性，不等于物理精度证明。

本次自动化使用独立Chrome及SwiftShader；Codex内嵌浏览器连接不可用，不以此声称全平台实机验收。后续砖形及边缘等待用户参考，不自行扩大本轮范围。当前材质方向获用户基本认可，修复后的最终用户验收与完整对象生产批准不代签。

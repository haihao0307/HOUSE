from pathlib import Path
import math,json,re
root=Path(__file__).resolve().parent
old=(root/'material-microscope-lab-r2/Brick_Material_Microscope_Lab_R2.html').read_text(encoding='utf-8')
new=(root/'material-microscope-lab-r2-1/Brick_Material_Microscope_Lab_R2_1.html').read_text(encoding='utf-8')
def field(x,y,z,scale,fixed):
    q=[a*9.5*scale for a in [x,y,z]];x,y,z=q;r=math.sqrt(x*x+y*y+z*z)
    if fixed:
        cap=.13*9.5*scale;rxy=math.sqrt(x*x+y*y+cap*cap*math.exp(-(x*x+y*y)/(cap*cap)))
        angle=math.acos(max(-.999999,min(.999999,y/rxy)))
    else:angle=math.atan2(x,y)
    xi=[math.log2(r)-2,-z/r-1,angle];s=0
    for j in range(17):
        sc=2**j;c=[math.cos(a*sc) for a in xi]
        s+=(math.cos(c[2]*c[0]+c[1]*c[1]+c[1]*c[0])-.6556965)/sc
    return s
checks={}
for name in ['processMaterial','map']:
    pattern=(r'Mat processMaterial\(.*?return m;\}' if name=='processMaterial' else r'vec2 map\(.*?return o;\}')
    checks[name+'_unchanged']=re.search(pattern,old,re.S).group()==re.search(pattern,new,re.S).group()
results=[]
for scale in [.25,1,4]:
    for z in [-.5,.5]:
        ring=lambda r,f:[field(r*math.sin(i*math.pi/32),r*math.cos(i*math.pi/32),z,scale,f) for i in range(64)]
        a=ring(1e-7,False);b=ring(1e-7,True);c=ring(1e-5,True)
        check=max(b)-min(b)<1e-4 and max(b)-min(b)<(max(a)-min(a))*.001 and all(math.isfinite(v) for v in b)
        checks[f'continuous_pole_{scale}_{z}']=check
        results.append({'scale':scale,'z':z,'oldAngularSpread':max(a)-min(a),'newAngularSpread':max(b)-min(b),'newOuterSpread':max(c)-min(c)})
report={'checks':checks,'results':results,'passed':all(checks.values()),'note':'CPU field continuity without screen gating; complementary to real-browser validation.'}
(root/'qa-r21/pole-continuity.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
assert report['passed']
